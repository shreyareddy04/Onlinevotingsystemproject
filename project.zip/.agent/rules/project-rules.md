# Project Rules for `election-vote`

## 1. Code Style & Standards
- Java 25 standard syntax.
- Use explicit Spring stereotyping (`@Service`, `@Repository`, `@Controller`, `@RestController`, `@Configuration`).
- Use Constructor Injection over field injection (`@Autowired`).

## 2. Security Requirements
- CSRF protection enabled on web forms.
- Passwords must be encoded using `BCryptPasswordEncoder`.
- Sensitive voter data must be isolated and protected by role-based authorization (`ROLE_ADMIN` vs `ROLE_VOTER`).

## 3. Database & JPA Rules
- H2 database in file or in-memory mode with `schema.sql` initialization.
- Models must specify standard JPA annotations (`@Entity`, `@Table`, `@Id`, `@GeneratedValue`, `@Column`, `@ManyToOne`, `@OneToMany`).
