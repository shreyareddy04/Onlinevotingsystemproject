# Launch Checklist (`LAUNCH.md`)

This checklist tracks production deployment readiness for the `election-vote` platform.

## Pre-Launch Requirements

- [ ] **Custom Domain & HTTPS**: A custom domain is connected and served exclusively over HTTPS.
- [x] **Favicon Assets**: `favicon.svg` and `favicon.ico` are present and linked in every page `<head>`.
- [x] **AI Tag Check**: Zero "Made with AI" tags or comments exist anywhere in the codebase.
- [x] **Privacy Policy & Terms**: `privacy.html` and `terms.html` exist, are linked in the footer, and accurately state what data is stored (passkey public key, voter identifier, eligibility record, ballot hash; zero biometric data).
- [ ] **WebAuthn Production Config**: `webauthn.hostname` (rpId) and origins are updated from `localhost` to the production domain name.

> **Status**: Local development environment on `http://localhost:8080`.
