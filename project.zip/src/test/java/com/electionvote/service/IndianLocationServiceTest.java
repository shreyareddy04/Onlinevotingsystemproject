package com.electionvote.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

class IndianLocationServiceTest {

    private final IndianLocationService locations = new IndianLocationService(new ObjectMapper());

    @Test
    void canonicalizesValidDistrictAndStatePair() {
        assertEquals("Hyderabad, Telangana",
                locations.normalizeDistrictAndState("  Hyderabad , Telangana  "));
    }

    @Test
    void rejectsDistrictAndStateThatDoNotBelongTogether() {
        assertThrows(IllegalArgumentException.class,
                () -> locations.normalizeDistrictAndState("Hyderabad, Andhra Pradesh"));
    }

    @Test
    void rejectsOldGenericPlaceholderDistrict() {
        assertThrows(IllegalArgumentException.class,
                () -> locations.normalizeDistrictAndState("North District, Telangana"));
    }
}
