package com.electionvote;

import com.electionvote.model.Voter;
import com.electionvote.model.Candidate;
import com.electionvote.model.Election;
import com.electionvote.model.Ballot;
import com.electionvote.repository.BallotRepository;
import com.electionvote.repository.CandidateRepository;
import com.electionvote.repository.EligibilityRecordRepository;
import com.electionvote.repository.ElectionRepository;
import com.electionvote.repository.VoteReceiptRepository;
import com.electionvote.repository.VoterRepository;
import com.electionvote.service.ElectionService;
import com.electionvote.service.VotingService;
import org.springframework.mock.web.MockHttpSession;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.transaction.annotation.Transactional;
import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Instant;
import java.time.LocalDateTime;
import java.util.List;

import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.csrf;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.user;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import static org.hamcrest.Matchers.containsString;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.multipart;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest(properties = {
        "demo.otp-fallback-enabled=true",
        "msg91.auth-key=",
        "msg91.otp.template-id="
})
@AutoConfigureMockMvc
public class PageSmokeTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ElectionRepository electionRepository;

    @Autowired
    private CandidateRepository candidateRepository;

    @Autowired
    private BallotRepository ballotRepository;

    @Autowired
    private EligibilityRecordRepository eligibilityRecordRepository;

    @Autowired
    private VoteReceiptRepository voteReceiptRepository;

    @Autowired
    private VoterRepository voterRepository;

    @Autowired
    private VotingService votingService;

    @Autowired
    private ElectionService electionService;

    @Test
    public void testHomePage() throws Exception {
        mockMvc.perform(get("/"))
                .andExpect(status().isOk())
                .andExpect(view().name("index"))
                .andExpect(content().string(containsString("name=\"voterId\"")))
                .andExpect(content().string(containsString("name=\"voterIdFront\"")))
                .andExpect(content().string(containsString("name=\"voterIdBack\"")))
                .andExpect(content().string(org.hamcrest.Matchers.not(containsString(">01</span>"))))
                .andExpect(content().string(org.hamcrest.Matchers.not(containsString(">02</span>"))))
                .andExpect(content().string(containsString("class=\"admin-login-menu\"")))
                .andExpect(content().string(containsString("Administrator access</summary>")))
                .andExpect(content().string(containsString("admin-login-toggle")))
                .andExpect(content().string(containsString("name=\"username\"")))
                .andExpect(content().string(containsString("Local demo identity check")))
                .andExpect(content().string(containsString("placeholder=\"Enter your voter ID number\"")))
                .andExpect(content().string(containsString("Create an account</a>")))
                .andExpect(content().string(org.hamcrest.Matchers.not(containsString("SECURE VOTING PORTAL"))))
                .andExpect(content().string(org.hamcrest.Matchers.not(containsString("Choose the sign-in option that matches your role."))))
                .andExpect(content().string(org.hamcrest.Matchers.not(containsString("name=\"email\""))))
                .andExpect(content().string(org.hamcrest.Matchers.not(containsString("Elections Directory"))))
                .andExpect(content().string(org.hamcrest.Matchers.not(containsString("navbar-votesphere"))));
    }

    @Test
    public void testIndianDistrictDirectoryIsPublicJson() throws Exception {
        mockMvc.perform(get("/data/india-states-districts.json"))
                .andExpect(status().isOk())
                .andExpect(content().contentTypeCompatibleWith("application/json"))
                .andExpect(content().string(containsString("Telangana")))
                .andExpect(content().string(containsString("\"Hyderabad\"")));
    }

    @Test
    public void testCandidateRegistrationIsPublicAndExplainsReview() throws Exception {
        mockMvc.perform(get("/candidate/register"))
                .andExpect(status().isOk())
                .andExpect(view().name("candidate-registration"))
                .andExpect(content().string(containsString("Register as a candidate")))
                .andExpect(content().string(containsString("administrator must review and approve your profile")))
                .andExpect(content().string(containsString("no elections currently accepting candidate registrations")));
    }

    @Test
    public void testCandidateSubmissionStaysHiddenUntilAdminApprovesIt() throws Exception {
        String suffix = Long.toString(System.nanoTime());
        Election election = electionRepository.save(new Election(
                "Candidate Registration Test " + suffix, "Test election", "Assembly", "UPCOMING",
                LocalDateTime.now().plusDays(3), LocalDateTime.now().plusDays(10)));
        byte[] image = createPngImage();
        Candidate submitted = null;
        try {
            mockMvc.perform(multipart("/candidate/register")
                            .file(new MockMultipartFile("photo", "candidate.png", "image/png", image))
                            .file(new MockMultipartFile("partySymbol", "symbol.png", "image/png", image))
                            .with(csrf())
                            .param("electionId", election.getId().toString())
                            .param("name", "Candidate " + suffix)
                            .param("party", "Indian National Congress")
                            .param("position", "Member of Legislative Assembly")
                            .param("constituency", "Hyderabad, Telangana")
                            .param("bio", "Promises improved public transport."))
                    .andExpect(status().isOk())
                    .andExpect(view().name("candidate-registration-submitted"))
                    .andExpect(content().string(containsString("after an administrator approves them")));

            submitted = candidateRepository.findByElectionId(election.getId()).stream()
                    .filter(candidate -> candidate.getName().equals("Candidate " + suffix))
                    .findFirst().orElseThrow();
            assertFalse(submitted.isApproved());
            Long submittedCandidateId = submitted.getId();
            assertFalse(electionService.findApprovedCandidatesByElectionId(election.getId()).stream()
                    .anyMatch(candidate -> candidate.getId().equals(submittedCandidateId)));

            mockMvc.perform(get("/admin/candidates/" + election.getId())
                            .with(user("admin").roles("ADMIN")))
                    .andExpect(status().isOk())
                    .andExpect(view().name("admin/candidates"))
                    .andExpect(content().string(containsString("data-location-state")))
                    .andExpect(content().string(containsString("Pending review")));

            mockMvc.perform(multipart("/admin/candidate/save")
                            .with(csrf())
                            .with(user("admin").roles("ADMIN"))
                            .param("candidateId", submitted.getId().toString())
                            .param("electionId", election.getId().toString())
                            .param("name", "Approved Candidate " + suffix)
                            .param("party", "Bharatiya Janata Party")
                            .param("position", "Member of Legislative Assembly")
                            .param("constituency", "Hyderabad, Telangana")
                            .param("bio", "Promises better public services.")
                            .param("approved", "true"))
                    .andExpect(status().is3xxRedirection())
                    .andExpect(redirectedUrl("/admin/candidates/" + election.getId()));

            Candidate approved = candidateRepository.findById(submitted.getId()).orElseThrow();
            assertTrue(approved.isApproved());
            assertEquals("Approved Candidate " + suffix, approved.getName());
            assertEquals("Promises better public services.", approved.getBio());
            assertTrue(electionService.findApprovedCandidatesByElectionId(election.getId()).stream()
                    .anyMatch(candidate -> candidate.getId().equals(submittedCandidateId)));
        } finally {
            List<Candidate> createdCandidates = candidateRepository.findByElectionId(election.getId());
            for (Candidate candidate : createdCandidates) {
                deleteCandidateImage(candidate.getPhotoUrl());
                deleteCandidateImage(candidate.getPartySymbolUrl());
            }
            candidateRepository.deleteAll(createdCandidates);
            electionRepository.deleteById(election.getId());
        }
    }

    @Test
    public void testVoterLoginRejectsAnIdNotInTheLocalVoterRecords() throws Exception {
        mockMvc.perform(multipart("/voter-login")
                        .file(new MockMultipartFile("voterIdFront", "", "image/png", new byte[0]))
                        .file(new MockMultipartFile("voterIdBack", "", "image/png", new byte[0]))
                        .with(csrf())
                        .param("voterId", "NO-SUCH-VOTER"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/"));
    }

    @Test
    public void testVoterLoginRejectsInvalidIdCharacters() throws Exception {
        for (String voterId : new String[]{"ABC.123", "ABC/123"}) {
            mockMvc.perform(multipart("/voter-login")
                            .file(new MockMultipartFile("voterIdFront", "", "image/png", new byte[0]))
                            .file(new MockMultipartFile("voterIdBack", "", "image/png", new byte[0]))
                            .with(csrf())
                            .param("voterId", voterId))
                    .andExpect(status().is3xxRedirection())
                    .andExpect(redirectedUrl("/"))
                    .andExpect(flash().attribute("voterErrorMessage",
                            "Voter ID numbers may contain only letters, numbers, spaces, and hyphens."));
        }
    }

    @Test
    public void testMatchedVoterContinuesToMobileStepWithoutEmail() throws Exception {
        String username = "voter-login-" + System.nanoTime();
        String voterId = "TST-" + String.format("%07d", System.nanoTime() % 10_000_000);
        Voter voter = voterRepository.save(new Voter(
                username, username + "@example.com", "unused", "Demo Voter",
                voterId, "9876543210", "Hyderabad, Telangana", "ROLE_VOTER"));
        var elections = electionRepository.findAll();
        assertFalse(elections.isEmpty(), "Demo data should include an election");

        byte[] image = createPngImage();
        try {
            MvcResult loginResult = mockMvc.perform(multipart("/voter-login")
                            .file(new MockMultipartFile("voterIdFront", "front.png", "image/png", image))
                            .file(new MockMultipartFile("voterIdBack", "back.png", "image/png", image))
                            .with(csrf())
                            .param("voterId", voter.getNationalId().toLowerCase().replace("-", " ")))
                    .andExpect(status().is3xxRedirection())
                    .andExpect(redirectedUrl("/elections"))
                    .andReturn();

            MockHttpSession session = (MockHttpSession) loginResult.getRequest().getSession(false);
            assertNotNull(session);
            mockMvc.perform(get("/elections").session(session))
                    .andExpect(status().isOk())
                    .andExpect(content().string(containsString("Choose your election")))
                    .andExpect(content().string(containsString("local demo")));
            Long electionId = elections.getFirst().getId();
            mockMvc.perform(get("/ballot/" + electionId).session(session))
                    .andExpect(status().is3xxRedirection())
                    .andExpect(redirectedUrl("/ballot/wizard/" + electionId + "/step2"));
            mockMvc.perform(get("/ballot/wizard/" + electionId + "/step2").session(session))
                    .andExpect(status().isOk())
                    .andExpect(content().string(containsString("Confirm your registered mobile")))
                    .andExpect(content().string(containsString("name=\"mobileNumber\"")))
                    .andExpect(content().string(containsString("placeholder=\"Enter your 10-digit Indian mobile number\"")))
                    .andExpect(content().string(org.hamcrest.Matchers.not(containsString("value=\"9876543210\""))))
                    .andExpect(content().string(org.hamcrest.Matchers.not(containsString("readonly"))));
        } finally {
            voterRepository.findByUsername(username).ifPresent(saved -> {
                try {
                    if (saved.getVoterIdFrontPath() != null) {
                        Files.deleteIfExists(Path.of(saved.getVoterIdFrontPath()));
                    }
                    if (saved.getVoterIdBackPath() != null) {
                        Files.deleteIfExists(Path.of(saved.getVoterIdBackPath()));
                    }
                } catch (java.io.IOException e) {
                    throw new IllegalStateException("Could not clean up test voter ID photos", e);
                }
                voterRepository.delete(saved);
            });
        }
    }

    @Test
    public void testVerifiedPasskeyStepShowsElectionWidePresidentCandidateAndManifesto() throws Exception {
        String username = "step5-voter-" + System.nanoTime();
        Voter voter = voterRepository.save(new Voter(
                username, username + "@example.com", "unused", "Ballot Test Voter",
                "TST-" + System.nanoTime(), "9876543210", "Nizamabad, Telangana", "ROLE_VOTER"));
        Election election = electionRepository.save(new Election(
                "Election-Wide President Ballot Test", "Test election", "Assembly", "ACTIVE",
                LocalDateTime.now(), LocalDateTime.now().plusDays(1)));
        Candidate candidate = new Candidate(
                "Asha Candidate", "Indian National Congress (INC)", "President",
                "Hyderabad, Telangana", "Promises better local transport.\nImprove access to public clinics.",
                null, election);
        candidate.setNota(null);
        candidate.setPhotoUrl("/candidate-images/asha-candidate.png");
        candidate.setPartySymbolUrl("/candidate-images/inc-symbol.png");
        candidate = candidateRepository.saveAndFlush(candidate);

        MockHttpSession session = new MockHttpSession();
        session.setAttribute("voting_election_id", election.getId());
        session.setAttribute("step1_verified", true);
        session.setAttribute("step2_verified", true);
        session.setAttribute("step3_verified", true);
        session.setAttribute("biometric_verified_election_id", election.getId());

        try {
            mockMvc.perform(get("/ballot/wizard/" + election.getId() + "/step5")
                            .session(session)
                            .with(user(username).roles("VOTER")))
                    .andExpect(status().isOk())
                    .andExpect(view().name("voter-verification"))
                    .andExpect(content().string(containsString("Candidates standing in this election")))
                    .andExpect(content().string(containsString("Your area: Nizamabad, Telangana")))
                    .andExpect(content().string(containsString("Asha Candidate")))
                    .andExpect(content().string(containsString("Indian National Congress (INC)")))
                    .andExpect(content().string(containsString("candidate-ballot-grid")))
                    .andExpect(content().string(containsString("candidate-card-photo")))
                    .andExpect(content().string(containsString("candidate-party-heading")))
                    .andExpect(content().string(containsString("/candidate-images/inc-symbol.png")))
                    .andExpect(content().string(containsString("/candidate-images/asha-candidate.png")))
                    .andExpect(content().string(containsString("Standing for: President")))
                    .andExpect(content().string(containsString("Promises better local transport.")))
                    .andExpect(content().string(containsString("Improve access to public clinics.")))
                    .andExpect(content().string(containsString("Hyderabad, Telangana")));

            mockMvc.perform(post("/ballot/confirm-vote")
                            .session(session)
                            .with(user(username).roles("VOTER"))
                            .with(csrf())
                            .param("electionId", election.getId().toString())
                            .param("candidateId", candidate.getId().toString()))
                    .andExpect(status().isOk())
                    .andExpect(view().name("review"))
                    .andExpect(content().string(containsString("Please confirm your vote")))
                    .andExpect(content().string(containsString("Asha Candidate")))
                    .andExpect(content().string(containsString(">Confirm</button>")))
                    .andExpect(content().string(org.hamcrest.Matchers.not(containsString("You can cast only one vote"))))
                    .andExpect(content().string(containsString("name=\"electionId\"")))
                    .andExpect(content().string(org.hamcrest.Matchers.not(containsString("name=\"candidateId\""))));
            assertFalse(votingService.hasAlreadyVoted(voter, election),
                    "Showing the review screen must not cast the ballot.");

            mockMvc.perform(post("/ballot/final-confirmation")
                            .session(session)
                            .with(user(username).roles("VOTER"))
                            .with(csrf())
                            .param("electionId", election.getId().toString()))
                    .andExpect(status().isOk())
                    .andExpect(view().name("vote-confirmation"))
                    .andExpect(content().string(containsString("You can cast only one vote")))
                    .andExpect(content().string(containsString("Once confirmed, your vote cannot be changed")))
                    .andExpect(content().string(containsString("name=\"electionId\"")));
            assertFalse(votingService.hasAlreadyVoted(voter, election),
                    "The warning page must not cast the ballot before the voter confirms.");

            MvcResult castResult = mockMvc.perform(post("/ballot/cast-vote")
                            .session(session)
                            .with(user(username).roles("VOTER"))
                            .with(csrf())
                            .param("electionId", election.getId().toString()))
                    .andExpect(status().is3xxRedirection())
                    .andExpect(redirectedUrl("/confirmation"))
                    .andExpect(flash().attribute("voterName", voter.getFullName()))
                    .andExpect(flash().attribute("voterId", voter.getNationalId()))
                    .andReturn();
            assertTrue(votingService.hasAlreadyVoted(voter, election),
                    "The ballot should be recorded only after final confirmation.");

            mockMvc.perform(get("/confirmation").flashAttrs(castResult.getFlashMap()))
                    .andExpect(status().isOk())
                    .andExpect(view().name("confirmation"))
                    .andExpect(content().string(containsString("Your vote has been successfully cast")))
                    .andExpect(content().string(containsString("Ballot Test Voter")))
                    .andExpect(content().string(containsString(voter.getNationalId())))
                    .andExpect(content().string(org.hamcrest.Matchers.not(containsString("Asha Candidate"))))
                    .andExpect(content().string(org.hamcrest.Matchers.not(containsString("SHA-256"))))
                    .andExpect(content().string(org.hamcrest.Matchers.not(containsString("Receipt Code"))))
                    .andExpect(content().string(org.hamcrest.Matchers.not(containsString("Election-Wide President Ballot Test"))))
                    .andExpect(content().string(containsString("name=\"_csrf\"")))
                    .andExpect(content().string(containsString(">Log out</button>")))
                    .andExpect(content().string(org.hamcrest.Matchers.not(containsString("Return to Elections Directory"))))
                    .andExpect(content().string(org.hamcrest.Matchers.not(containsString("Return to sign in"))));
        } finally {
            voteReceiptRepository.deleteAll(voteReceiptRepository.findByVoterId(voter.getId()));
            ballotRepository.deleteAll(ballotRepository.findByElectionId(election.getId()));
            eligibilityRecordRepository.deleteAll(eligibilityRecordRepository.findByVoter(voter));
            candidateRepository.delete(candidate);
            electionRepository.delete(election);
            voterRepository.delete(voter);
        }
    }

    private static byte[] createPngImage() throws Exception {
        BufferedImage image = new BufferedImage(1, 1, BufferedImage.TYPE_INT_RGB);
        ByteArrayOutputStream output = new ByteArrayOutputStream();
        ImageIO.write(image, "png", output);
        return output.toByteArray();
    }

    private static void deleteCandidateImage(String url) throws Exception {
        if (url != null && url.startsWith("/candidate-images/")) {
            Files.deleteIfExists(Path.of("data/candidate-images")
                    .resolve(url.substring("/candidate-images/".length())));
        }
    }

    @Test
    public void testElectionsPage() throws Exception {
        mockMvc.perform(get("/elections"))
                .andExpect(status().isOk())
                .andExpect(view().name("elections"))
                .andExpect(content().string(org.hamcrest.Matchers.not(containsString("Search by title"))))
                .andExpect(content().string(org.hamcrest.Matchers.not(containsString("electionSearchInput"))))
                .andExpect(content().string(org.hamcrest.Matchers.not(containsString(">Search</button>"))));
    }

    @Test
    public void testHowItWorksPage() throws Exception {
        mockMvc.perform(get("/how-it-works"))
                .andExpect(status().isOk())
                .andExpect(view().name("how-it-works"));
    }

    @Test
    public void testHelpPage() throws Exception {
        mockMvc.perform(get("/help"))
                .andExpect(status().isOk())
                .andExpect(view().name("help"));
    }

    @Test
    public void testContactPage() throws Exception {
        mockMvc.perform(get("/contact"))
                .andExpect(status().isOk())
                .andExpect(view().name("contact"));
    }

    @Test
    public void testPrivacyPage() throws Exception {
        mockMvc.perform(get("/privacy"))
                .andExpect(status().isOk())
                .andExpect(view().name("privacy"));
    }

    @Test
    public void testTermsPage() throws Exception {
        mockMvc.perform(get("/terms"))
                .andExpect(status().isOk())
                .andExpect(view().name("terms"));
    }

    @Test
    public void testLoginPage() throws Exception {
        mockMvc.perform(get("/login"))
                .andExpect(status().isOk())
                .andExpect(view().name("index"));
    }

    @Test
    public void testPasswordLoginRejectsVoterAccounts() throws Exception {
        mockMvc.perform(post("/login")
                        .with(csrf())
                        .param("username", "voter1")
                        .param("password", "VoterPass123!"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/?error"));
    }

    @Test
    public void testRegisterPage() throws Exception {
        mockMvc.perform(get("/register"))
                .andExpect(status().isOk())
                .andExpect(view().name("register"))
                .andExpect(content().string(containsString("name=\"nationalId\"")))
                .andExpect(content().string(containsString("name=\"mobileNumber\"")))
                .andExpect(content().string(containsString("name=\"constituency\"")))
                .andExpect(content().string(containsString("data-location-state")))
                .andExpect(content().string(containsString("data-location-district")))
                .andExpect(content().string(containsString("name=\"voterIdFront\"")))
                .andExpect(content().string(containsString("name=\"voterIdBack\"")))
                .andExpect(content().string(org.hamcrest.Matchers.not(containsString("name=\"email\""))))
                .andExpect(content().string(org.hamcrest.Matchers.not(containsString("name=\"password\""))));
    }

    @Test
    public void testVoterRegistrationSavesTheSubmittedConstituency() throws Exception {
        String nationalId = "REG-" + String.format("%07d", System.nanoTime() % 10_000_000);
        byte[] image = createPngImage();

        try {
            mockMvc.perform(multipart("/register")
                            .file(new MockMultipartFile("voterIdFront", "front.png", "image/png", image))
                            .file(new MockMultipartFile("voterIdBack", "back.png", "image/png", image))
                            .with(csrf())
                            .param("nationalId", nationalId)
                            .param("mobileNumber", "9876543210")
                            .param("constituency", "Hyderabad, Telangana"))
                    .andExpect(status().is3xxRedirection())
                    .andExpect(redirectedUrl("/register/passkey"));

            Voter voter = voterRepository.findByNationalIdIgnoreCase(nationalId.replace("-", "")).orElseThrow();
            assertEquals("Hyderabad, Telangana", voter.getConstituency());
        } finally {
            voterRepository.findByNationalIdIgnoreCase(nationalId.replace("-", "")).ifPresent(voter -> {
                try {
                    if (voter.getVoterIdFrontPath() != null) {
                        Files.deleteIfExists(Path.of(voter.getVoterIdFrontPath()));
                    }
                    if (voter.getVoterIdBackPath() != null) {
                        Files.deleteIfExists(Path.of(voter.getVoterIdBackPath()));
                    }
                } catch (java.io.IOException e) {
                    throw new IllegalStateException("Could not clean up test voter ID photos", e);
                }
                voterRepository.delete(voter);
            });
        }
    }

    @Test
    public void testVoterCanUpdateConstituencyFromAccount() throws Exception {
        String username = "constituency-voter-" + System.nanoTime();
        Voter voter = voterRepository.save(new Voter(
                username, username + "@example.com", "unused", "Constituency Test Voter",
                "TST-" + System.nanoTime(), "9876543210", "Hyderabad, Telangana", "ROLE_VOTER"));

        try {
            mockMvc.perform(post("/account/constituency")
                            .with(user(username).roles("VOTER"))
                            .with(csrf())
                            .param("constituency", "Nizamabad, Telangana"))
                    .andExpect(status().is3xxRedirection())
                    .andExpect(redirectedUrl("/account"))
                    .andExpect(flash().attribute("successMessage", "Your constituency was updated."));

            assertEquals("Nizamabad, Telangana",
                    voterRepository.findByUsername(username).orElseThrow().getConstituency());
        } finally {
            voterRepository.delete(voter);
        }
    }

    @Test
    public void testAdminRegistrationPageIsAvailableForNewAdministrators() throws Exception {
        mockMvc.perform(get("/admin/register"))
                .andExpect(status().isOk())
                .andExpect(view().name("admin/register"))
                .andExpect(content().string(containsString("name=\"confirmPassword\"")));
    }

    @Test
    @WithMockUser(username = "admin", roles = "ADMIN")
    public void testAdministratorCanOpenAdminRegistration() throws Exception {
        mockMvc.perform(get("/admin/register"))
                .andExpect(status().isOk())
                .andExpect(view().name("admin/register"));
    }

    @Test
    public void testAdminRegistrationRequiresMatchingPasswordConfirmation() throws Exception {
        mockMvc.perform(post("/admin/register")
                        .with(csrf())
                        .param("email", "new-admin-" + System.nanoTime() + "@example.com")
                        .param("password", "SecurePass123!")
                        .param("confirmPassword", "DifferentPass123!"))
                .andExpect(status().isOk())
                .andExpect(view().name("admin/register"))
                .andExpect(model().attribute("errorMessage",
                        "The passwords do not match. Re-enter them and try again."));
    }

    @Test
    public void testNewAdminCanRegisterAndLogInWithEmail() throws Exception {
        String email = "new-admin-" + System.nanoTime() + "@example.com";
        String password = "SecurePass123!";
        mockMvc.perform(post("/admin/register")
                        .with(csrf())
                        .param("email", email)
                        .param("password", password)
                        .param("confirmPassword", password))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/login?registered=admin"));

        assertTrue(voterRepository.findByEmailIgnoreCase(email)
                .filter(voter -> "ROLE_ADMIN".equals(voter.getRole()))
                .isPresent());
        mockMvc.perform(post("/login")
                        .with(csrf())
                        .param("username", email.toUpperCase())
                        .param("password", password))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/admin/dashboard"));
    }

    @Test
    public void testVoterRegistrationNormalizesNationalIdBeforeLogin() throws Exception {
        String nationalId = "TST-" + String.format("%07d", System.nanoTime() % 10_000_000);
        byte[] image = createPngImage();
        try {
            MvcResult result = mockMvc.perform(multipart("/register")
                        .file(new MockMultipartFile("voterIdFront", "front.png", "image/png", image))
                        .file(new MockMultipartFile("voterIdBack", "back.png", "image/png", image))
                        .with(csrf())
                        .param("nationalId", " " + nationalId.toLowerCase().replace("-", " ") + " ")
                        .param("mobileNumber", "+91 98765-43210")
                        .param("constituency", "Hyderabad, Telangana"))
                    .andExpect(status().is3xxRedirection())
                    .andExpect(redirectedUrl("/register/passkey"))
                    .andReturn();

            MockHttpSession session = (MockHttpSession) result.getRequest().getSession(false);
            assertNotNull(session);
            Voter voter = voterRepository.findByNationalIdIgnoreCase(nationalId.replace("-", ""))
                    .orElseThrow();
            assertEquals("9876543210", voter.getMobileNumber());
            assertTrue(voter.getEmail().endsWith("@voter.local.invalid"));
            mockMvc.perform(get("/register/passkey").session(session))
                    .andExpect(status().isOk())
                    .andExpect(view().name("register-passkey"))
                    .andExpect(content().string(containsString("data-registration-complete=\"true\"")));
            mockMvc.perform(get("/api/webauthn/register/options").session(session))
                    .andExpect(status().isOk())
                    .andExpect(content().string(containsString("\"publicKey\"")));
        } finally {
            voterRepository.findByNationalIdIgnoreCase(nationalId.replace("-", "")).ifPresent(saved -> {
                deleteVoterIdImages(saved);
                voterRepository.delete(saved);
            });
        }
    }

    @Test
    public void testVoterRegistrationRejectsInvalidIndianMobileNumber() throws Exception {
        byte[] image = createPngImage();
        mockMvc.perform(multipart("/register")
                        .file(new MockMultipartFile("voterIdFront", "front.png", "image/png", image))
                        .file(new MockMultipartFile("voterIdBack", "back.png", "image/png", image))
                        .with(csrf())
                        .param("nationalId", "PHONE" + System.nanoTime())
                        .param("mobileNumber", "1234567890"))
                .andExpect(status().isOk())
                .andExpect(view().name("register"))
                .andExpect(model().attribute("errorMessage",
                        "Enter a valid 10-digit Indian mobile number starting with 6, 7, 8, or 9."));
    }

    private void deleteVoterIdImages(Voter voter) {
        try {
            if (voter.getVoterIdFrontPath() != null) {
                Files.deleteIfExists(Path.of(voter.getVoterIdFrontPath()));
            }
            if (voter.getVoterIdBackPath() != null) {
                Files.deleteIfExists(Path.of(voter.getVoterIdBackPath()));
            }
        } catch (java.io.IOException e) {
            throw new IllegalStateException("Could not clean up test voter ID photos", e);
        }
    }

    @Test
    @WithMockUser(username = "voter1", roles = "VOTER")
    public void testVoterCannotSkipVerificationSteps() throws Exception {
        mockMvc.perform(get("/ballot/wizard/1/step5"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/ballot/wizard/1/step1"));
    }

    @Test
    @WithMockUser(username = "voter1", roles = "VOTER")
    public void testVoterVerificationPageRequiresBothIdImages() throws Exception {
        var elections = electionRepository.findAll();
        assertFalse(elections.isEmpty(), "Demo data should include an election");
        mockMvc.perform(get("/ballot/wizard/" + elections.getFirst().getId() + "/step1"))
                .andExpect(status().isOk())
                .andExpect(view().name("voter-verification"))
                .andExpect(content().string(containsString("name=\"voterIdFront\"")))
                .andExpect(content().string(containsString("name=\"voterIdBack\"")));
    }

    @Test
    @WithMockUser(username = "voter1", roles = "VOTER")
    public void testOtpVerificationPageNeverDisplaysTheCode() throws Exception {
        Long electionId = electionRepository.findAll().getFirst().getId();
        MockHttpSession session = new MockHttpSession();
        session.setAttribute("voting_election_id", electionId);
        session.setAttribute("step1_verified", true);
        session.setAttribute("step2_verified", true);
        session.setAttribute("voting_otp_sent", true);
        session.setAttribute("voting_otp_expiry", Instant.now().plusSeconds(300));
        session.setAttribute("voting_otp_attempts", 0);

        mockMvc.perform(get("/ballot/wizard/" + electionId + "/step3").session(session))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("ending in")))
                .andExpect(content().string(org.hamcrest.Matchers.not(containsString("Local demo mode"))))
                .andExpect(content().string(org.hamcrest.Matchers.not(containsString("use <strong"))));
    }

    @Test
    @WithMockUser(username = "voter1", roles = "VOTER")
    public void testLocalOtpFallbackAdvancesAndAllowsDemoVerification() throws Exception {
        Long electionId = electionRepository.findAll().getFirst().getId();
        MockHttpSession session = new MockHttpSession();
        session.setAttribute("voting_election_id", electionId);
        session.setAttribute("step1_verified", true);

        MvcResult sendResult = mockMvc.perform(post("/ballot/wizard/" + electionId + "/send-otp")
                        .session(session)
                        .param("mobileNumber", "+91 98765-43210")
                        .with(csrf()))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/ballot/wizard/" + electionId + "/step3"))
                .andReturn();

        MockHttpSession otpSession = (MockHttpSession) sendResult.getRequest().getSession(false);
        assertNotNull(otpSession);
        String otpPage = mockMvc.perform(get("/ballot/wizard/" + electionId + "/step3").session(otpSession))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("Local demo OTP")))
                .andExpect(content().string(containsString("No SMS was sent")))
                .andReturn().getResponse().getContentAsString();
        java.util.regex.Matcher otpMatcher = java.util.regex.Pattern
                .compile("class=\"local-demo-otp\">([0-9]{6})</code>")
                .matcher(otpPage);
        assertTrue(otpMatcher.find(), "The fallback page should display a six-digit local code");

        mockMvc.perform(post("/ballot/wizard/" + electionId + "/step3")
                        .session(otpSession)
                        .with(csrf())
                        .param("otpCode", otpMatcher.group(1)))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/ballot/wizard/" + electionId + "/step4"));
    }

    @Test
    @WithMockUser(username = "voter1", roles = "VOTER")
    public void testLocalOtpFallbackIsNotAvailableThroughPublicProxy() throws Exception {
        Long electionId = electionRepository.findAll().getFirst().getId();
        MockHttpSession session = new MockHttpSession();
        session.setAttribute("voting_election_id", electionId);
        session.setAttribute("step1_verified", true);

        mockMvc.perform(post("/ballot/wizard/" + electionId + "/send-otp")
                        .session(session)
                        .header("X-Forwarded-Host", "public.example.ngrok-free.dev")
                        .header("X-Forwarded-Proto", "https")
                        .param("mobileNumber", "+91 98765-43210")
                        .with(csrf()))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/ballot/wizard/" + electionId + "/step2"))
                .andExpect(flash().attribute("errorMessage",
                        "MSG91 OTP is not configured. Set MSG91_AUTH_KEY and MSG91_OTP_TEMPLATE_ID."));
        assertFalse(Boolean.TRUE.equals(session.getAttribute("step2_verified")));
        assertEquals(null, session.getAttribute("voting_local_otp"));
    }

    @Test
    @WithMockUser(username = "voter1", roles = "VOTER")
    public void testOtpRequestRejectsMobileNumberNotSavedToVoterAccount() throws Exception {
        Long electionId = electionRepository.findAll().getFirst().getId();
        MockHttpSession session = new MockHttpSession();
        session.setAttribute("voting_election_id", electionId);
        session.setAttribute("step1_verified", true);

        mockMvc.perform(post("/ballot/wizard/" + electionId + "/send-otp")
                        .session(session)
                        .with(csrf())
                        .param("mobileNumber", "9876543211"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/ballot/wizard/" + electionId + "/step2"))
                .andExpect(flash().attribute("errorMessage",
                        "The mobile number does not match the one saved with your voter registration."));
        assertFalse(Boolean.TRUE.equals(session.getAttribute("step2_verified")));
    }

    @Test
    @WithMockUser(username = "voter1", roles = "VOTER")
    public void testVoteCannotBeCastBeforeAllVerificationSteps() throws Exception {
        mockMvc.perform(post("/ballot/cast-vote")
                        .with(csrf())
                        .param("electionId", "1")
                        .param("candidateId", "1"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/ballot/wizard/1/step1"));
    }

    @Test
    @WithMockUser(username = "admin", roles = "ADMIN")
    public void testAdministratorCannotOpenVoterBallotFlow() throws Exception {
        mockMvc.perform(get("/ballot/wizard/1/step1"))
                .andExpect(status().isForbidden());
    }

    @Test
    @WithMockUser(username = "admin", roles = "ADMIN")
    @Transactional
    public void testAdministratorCanViewAggregateLiveResultsWithoutVoterChoices() throws Exception {
        String suffix = Long.toString(System.nanoTime());
        Election election = electionRepository.saveAndFlush(new Election(
                "Live Results Test " + suffix, "Aggregate results test", "Assembly", "ACTIVE",
                LocalDateTime.now(), LocalDateTime.now().plusDays(1)));
        Candidate firstCandidate = candidateRepository.saveAndFlush(new Candidate(
                "Candidate Alpha " + suffix, "Party A", "Member", "Hyderabad, Telangana",
                "Candidate profile", null, election));
        Candidate secondCandidate = candidateRepository.saveAndFlush(new Candidate(
                "Candidate Beta " + suffix, "Party B", "Member", "Hyderabad, Telangana",
                "Candidate profile", null, election));
        Candidate unapprovedCandidate = new Candidate(
                "Vinay " + suffix, "BRS", "Member", "Hyderabad, Telangana",
                "Pending candidate profile", null, election);
        unapprovedCandidate.setApproved(false);
        unapprovedCandidate = candidateRepository.saveAndFlush(unapprovedCandidate);
        ballotRepository.saveAllAndFlush(List.of(
                new Ballot(election, firstCandidate, null, "receipt-hash-a"),
                new Ballot(election, firstCandidate, null, "receipt-hash-b"),
                new Ballot(election, secondCandidate, null, "receipt-hash-c"),
                new Ballot(election, unapprovedCandidate, null, "receipt-hash-e")));

        mockMvc.perform(get("/elections/" + election.getId()))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("View Live Results")))
                .andExpect(content().string(org.hamcrest.Matchers.not(containsString(
                        "/ballot/" + election.getId()))));

        String page = mockMvc.perform(get("/admin/elections/" + election.getId() + "/results"))
                .andExpect(status().isOk())
                .andExpect(view().name("results"))
                .andExpect(content().string(org.hamcrest.Matchers.not(containsString(
                        "Administrator view shows aggregate totals only"))))
                .andExpect(content().string(containsString("Live results refresh automatically.")))
                .andExpect(content().string(containsString("setInterval(refreshResults, 3000)")))
                .andExpect(content().string(containsString("Candidate Alpha " + suffix)))
                .andExpect(content().string(containsString("Candidate Beta " + suffix)))
                .andExpect(content().string(containsString("Vinay " + suffix)))
                .andExpect(content().string(containsString("(BRS)")))
                .andExpect(content().string(containsString("2 votes")))
                .andExpect(content().string(containsString("1 votes")))
                .andExpect(content().string(containsString("aria-valuenow=\"50.0\"")))
                .andReturn().getResponse().getContentAsString();

        assertFalse(page.contains("voter_id"));
        assertFalse(page.contains("voter-secret"));

        String resultsUrl = "/admin/elections/" + election.getId() + "/results/data";
        mockMvc.perform(get(resultsUrl))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.totalVotes").value(4))
                .andExpect(jsonPath("$.candidates[0].candidateId").value(firstCandidate.getId()))
                .andExpect(jsonPath("$.candidates[0].votes").value(2))
                .andExpect(jsonPath("$.candidates[1].candidateId").value(secondCandidate.getId()))
                .andExpect(jsonPath("$.candidates[1].votes").value(1))
                .andExpect(jsonPath("$.candidates[2].candidateId").value(unapprovedCandidate.getId()))
                .andExpect(jsonPath("$.candidates[2].candidateName").value("Vinay " + suffix))
                .andExpect(jsonPath("$.candidates[2].party").value("BRS"))
                .andExpect(jsonPath("$.candidates[2].votes").value(1))
                .andExpect(content().string(org.hamcrest.Matchers.not(containsString("voter"))));

        ballotRepository.saveAndFlush(new Ballot(election, secondCandidate, null, "receipt-hash-d"));
        mockMvc.perform(get(resultsUrl))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.totalVotes").value(5))
                .andExpect(jsonPath("$.candidates[0].candidateId").value(firstCandidate.getId()))
                .andExpect(jsonPath("$.candidates[0].votes").value(2))
                .andExpect(jsonPath("$.candidates[1].candidateId").value(secondCandidate.getId()))
                .andExpect(jsonPath("$.candidates[1].votes").value(2))
                .andExpect(jsonPath("$.candidates[2].candidateId").value(unapprovedCandidate.getId()))
                .andExpect(jsonPath("$.candidates[2].votes").value(1))
                .andExpect(content().string(org.hamcrest.Matchers.not(containsString("voter"))));

        mockMvc.perform(get("/results/" + election.getId()).with(user("voter").roles("VOTER")))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/elections/" + election.getId()));
    }

    @Test
    @WithMockUser(username = "voter1", roles = "VOTER")
    public void testVoterCannotViewAdministratorLiveResults() throws Exception {
        Long electionId = electionRepository.findAll().getFirst().getId();

        mockMvc.perform(get("/admin/elections/" + electionId + "/results"))
                .andExpect(status().isForbidden());
    }
}
