package com.electionvote;

import com.electionvote.model.Voter;
import com.electionvote.model.PasskeyCredential;
import com.electionvote.repository.PasskeyCredentialRepository;
import com.electionvote.repository.VoterRepository;
import com.electionvote.service.WebAuthnService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.Transactional;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
@Transactional
public class WebAuthnFlowTest {

    @Autowired
    private WebAuthnService webAuthnService;

    @Autowired
    private VoterRepository voterRepository;

    @Autowired
    private PasskeyCredentialRepository passkeyCredentialRepository;

    @Autowired
    private ObjectMapper objectMapper;

    @Test
    public void testRegistrationChallengeIsSingleUseAndRejectsFakeCredential() throws Exception {
        String username = "passkey-test-" + System.nanoTime();
        Voter voter = voterRepository.save(new Voter(
                username, username + "@example.com", "pass", "Passkey Test", "ID-" + username, "ROLE_VOTER"));
        String options = webAuthnService.generateRegistrationOptions(voter);
        var optionJson = objectMapper.readTree(options).get("publicKey");
        assertNotNull(optionJson);
        assertNotNull(optionJson.get("challenge"), options);
        String challenge = optionJson.get("challenge").asText();

        assertNotNull(challenge);
        assertThrows(IllegalArgumentException.class,
                () -> webAuthnService.finishRegistration(username, challenge, "{}"));
        assertThrows(IllegalArgumentException.class,
                () -> webAuthnService.finishRegistration(username, challenge, "{}"));
    }

    @Test
    public void testAssertionRequiresAnUnexpiredChallenge() {
        assertThrows(IllegalArgumentException.class,
                () -> webAuthnService.verifyAssertion("unknown-voter", "missing-challenge", "{}"));
    }

    @Test
    public void testLegacyMockPasskeyIsNotTreatedAsVerifiedCredential() {
        String username = "legacy-passkey-" + System.nanoTime();
        Voter voter = voterRepository.save(new Voter(
                username, username + "@example.com", "pass", "Legacy Test", "ID-" + username, "ROLE_VOTER"));
        passkeyCredentialRepository.save(new PasskeyCredential(
                "legacy-credential", "MOCK_PUBLIC_KEY_PEM", 0, "legacy-handle", voter));

        assertFalse(webAuthnService.hasPasskey(username));
        assertThrows(IllegalStateException.class, () -> webAuthnService.generateAssertionOptions(username));
    }
}
