package com.electionvote;

import com.electionvote.dto.BallotSubmissionDto;
import com.electionvote.model.*;
import com.electionvote.repository.*;
import com.electionvote.service.VotingService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.Transactional;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import java.time.LocalDateTime;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
@Transactional
public class VotingServiceTest {

    @Autowired
    private VotingService votingService;

    @Autowired
    private VoterRepository voterRepository;

    @Autowired
    private ElectionRepository electionRepository;

    @Autowired
    private CandidateRepository candidateRepository;

    @Autowired
    private EligibilityRecordRepository eligibilityRecordRepository;

    @PersistenceContext
    private EntityManager entityManager;

    private Voter testVoter;
    private Election openElection;
    private Election closedElection;
    private Candidate candidateOpen;
    private Candidate candidateClosed;

    @BeforeEach
    public void setup() {
        testVoter = voterRepository.save(new Voter("voter_test", "voter_test@example.com", "pass", "Test Voter", "VOT-11", "ROLE_VOTER"));
        openElection = electionRepository.save(new Election("Open Election", "Desc", "Cat", "OPEN", LocalDateTime.now(), LocalDateTime.now().plusDays(5)));
        closedElection = electionRepository.save(new Election("Closed Election", "Desc", "Cat", "CLOSED", LocalDateTime.now().minusDays(10), LocalDateTime.now().minusDays(1)));
        candidateOpen = candidateRepository.save(new Candidate("Candidate 1", "Party X", "Position", "Bio", null, openElection));
        candidateClosed = candidateRepository.save(new Candidate("Candidate 2", "Party Y", "Position", "Bio", null, closedElection));
    }

    @Test
    public void testCastVoteSuccess() {
        BallotSubmissionDto submission = new BallotSubmissionDto();
        submission.setElectionId(openElection.getId());
        submission.setCandidateId(candidateOpen.getId());

        VoteReceipt receipt = votingService.castVote(testVoter, submission);

        assertNotNull(receipt);
        assertNotNull(receipt.getReceiptCode());
        assertTrue(receipt.getReceiptCode().startsWith("REC-"));
        assertTrue(votingService.hasAlreadyVoted(testVoter, openElection));
    }

    @Test
    public void testPreventDoubleVote() {
        BallotSubmissionDto submission = new BallotSubmissionDto();
        submission.setElectionId(openElection.getId());
        submission.setCandidateId(candidateOpen.getId());

        votingService.castVote(testVoter, submission);

        IllegalStateException ex = assertThrows(IllegalStateException.class, () -> {
            votingService.castVote(testVoter, submission);
        });
        assertTrue(ex.getMessage().contains("already cast a ballot"));
    }

    @Test
    public void testClosedElectionRejection() {
        BallotSubmissionDto submission = new BallotSubmissionDto();
        submission.setElectionId(closedElection.getId());
        submission.setCandidateId(candidateClosed.getId());

        IllegalStateException ex = assertThrows(IllegalStateException.class, () -> {
            votingService.castVote(testVoter, submission);
        });
        assertTrue(ex.getMessage().contains("Voting is closed"));
    }

    @Test
    public void testIneligibleVoterRejection() {
        Voter ineligibleVoter = voterRepository.save(new Voter("ineligible", "ineligible@example.com", "pass", "Ineligible Voter", "VOT-99", "ROLE_VOTER"));
        eligibilityRecordRepository.save(new EligibilityRecord(ineligibleVoter, openElection, false, false));

        BallotSubmissionDto submission = new BallotSubmissionDto();
        submission.setElectionId(openElection.getId());
        submission.setCandidateId(candidateOpen.getId());

        IllegalStateException ex = assertThrows(IllegalStateException.class, () -> {
            votingService.castVote(ineligibleVoter, submission);
        });
        assertTrue(ex.getMessage().contains("not eligible"));
    }

    @Test
    public void testRejectCandidateFromAnotherElection() {
        BallotSubmissionDto submission = new BallotSubmissionDto();
        submission.setElectionId(openElection.getId());
        submission.setCandidateId(candidateClosed.getId());

        IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                () -> votingService.castVote(testVoter, submission));
        assertTrue(ex.getMessage().contains("does not belong to this election"));
    }

    @Test
    public void testRejectCandidateOutsideVoterConstituency() {
        Candidate northCandidate = candidateRepository.save(new Candidate(
                "District Candidate", "Party Z", "Position", "Nizamabad, Telangana", "Bio", null, openElection));
        BallotSubmissionDto submission = new BallotSubmissionDto();
        submission.setElectionId(openElection.getId());
        submission.setCandidateId(northCandidate.getId());

        IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                () -> votingService.castVote(testVoter, submission));
        assertTrue(ex.getMessage().contains("outside your constituency"));
    }

    @Test
    public void testPresidentCandidateIsAvailableAcrossConstituencies() {
        testVoter.setConstituency("Nizamabad, Telangana");
        voterRepository.save(testVoter);
        Candidate presidentCandidate = candidateRepository.save(new Candidate(
                "President Candidate", "Party Z", "President", "Hyderabad, Telangana", "Bio", null, openElection));
        BallotSubmissionDto submission = new BallotSubmissionDto();
        submission.setElectionId(openElection.getId());
        submission.setCandidateId(presidentCandidate.getId());

        VoteReceipt receipt = votingService.castVote(testVoter, submission);

        assertNotNull(receipt);
        assertTrue(votingService.hasAlreadyVoted(testVoter, openElection));
    }

    @Test
    public void testRejectUnapprovedCandidate() {
        Candidate pendingCandidate = candidateRepository.save(new Candidate(
                "Pending Candidate", "Party Z", "Position", "Hyderabad, Telangana", "Manifesto", null, openElection));
        pendingCandidate.setApproved(false);
        candidateRepository.saveAndFlush(pendingCandidate);
        BallotSubmissionDto submission = new BallotSubmissionDto();
        submission.setElectionId(openElection.getId());
        submission.setCandidateId(pendingCandidate.getId());

        IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                () -> votingService.castVote(testVoter, submission));
        assertTrue(ex.getMessage().contains("not approved"));
    }

    @Test
    public void testLegacyCandidateWithNullNotaFlagLoadsAsRegularCandidate() {
        Candidate legacyCandidate = new Candidate(
                "Legacy Candidate", "Indian National Congress", "Member of Legislative Assembly",
                "Hyderabad, Telangana", "Promises improved local transport.", null, openElection);
        legacyCandidate.setNota(null);
        long candidateId = candidateRepository.saveAndFlush(legacyCandidate).getId();

        entityManager.clear();

        Candidate loadedCandidate = candidateRepository.findById(candidateId).orElseThrow();
        assertFalse(loadedCandidate.isNota());
        assertEquals("Promises improved local transport.", loadedCandidate.getBio());
    }

    @Test
    public void testAdministratorCannotCastVote() {
        testVoter.setRole("ROLE_ADMIN");
        BallotSubmissionDto submission = new BallotSubmissionDto();
        submission.setElectionId(openElection.getId());
        submission.setCandidateId(candidateOpen.getId());

        IllegalStateException ex = assertThrows(IllegalStateException.class,
                () -> votingService.castVote(testVoter, submission));
        assertTrue(ex.getMessage().contains("Only voter accounts"));
    }
}
