package com.electionvote;

import com.electionvote.service.Msg91OtpService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.test.web.client.MockRestServiceServer;
import org.springframework.web.client.RestClient;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.header;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.method;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.requestTo;
import static org.springframework.test.web.client.response.MockRestResponseCreators.withSuccess;
import static org.springframework.test.web.client.response.MockRestResponseCreators.withBadRequest;
import static org.springframework.http.HttpMethod.GET;
import static org.springframework.http.HttpMethod.POST;
import static org.springframework.http.MediaType.APPLICATION_JSON;

class Msg91OtpServiceTest {

    private static final String BASE_URL = "https://control.msg91.com/api/v5/otp";

    private RestClient.Builder restClientBuilder;
    private MockRestServiceServer server;
    private Msg91OtpService service;

    @BeforeEach
    void setUp() {
        restClientBuilder = RestClient.builder();
        server = MockRestServiceServer.bindTo(restClientBuilder).build();
        service = new Msg91OtpService(restClientBuilder, "test-auth-key", "test-template", BASE_URL);
    }

    @Test
    void sendsOtpUsingConfiguredTemplateAndFiveMinuteExpiry() {
        server.expect(requestTo(BASE_URL + "?authkey=test-auth-key&template_id=test-template&mobile=919876543210&otp_expiry=5&otp_length=6"))
                .andExpect(method(POST))
                .andRespond(withSuccess("{\"type\":\"success\"}", APPLICATION_JSON));

        service.sendOtp("9876543210");
        server.verify();
    }

    @Test
    void verifiesOtpWithMsg91AndInternationalMobileNumber() {
        server.expect(requestTo(BASE_URL + "/verify?mobile=919876543210&otp=123456"))
                .andExpect(method(GET))
                .andExpect(header("authkey", "test-auth-key"))
                .andRespond(withSuccess("{\"type\":\"success\"}", APPLICATION_JSON));

        assertTrue(service.verifyOtp("9876543210", "123456"));
        server.verify();
    }

    @Test
    void returnsFalseWhenMsg91RejectsOtp() {
        server.expect(requestTo(BASE_URL + "/verify?mobile=919876543210&otp=000000"))
                .andRespond(withSuccess("{\"type\":\"error\"}", APPLICATION_JSON));

        assertFalse(service.verifyOtp("9876543210", "000000"));
        server.verify();
    }

    @Test
    void reportsMissingCredentialsInsteadOfFallingBackToAnOnScreenOtp() {
        Msg91OtpService unconfigured = new Msg91OtpService(
                RestClient.builder(), "", "", BASE_URL);

        assertThrows(IllegalStateException.class, () -> unconfigured.sendOtp("9876543210"));
    }

    @Test
    void throwsWhenProviderRejectsOtpSend() {
        server.expect(requestTo(BASE_URL + "?authkey=test-auth-key&template_id=test-template&mobile=919876543210&otp_expiry=5&otp_length=6"))
                .andRespond(withBadRequest().body("{\"type\":\"error\"}"));

        assertThrows(org.springframework.web.client.RestClientException.class,
                () -> service.sendOtp("9876543210"));
    }
}
