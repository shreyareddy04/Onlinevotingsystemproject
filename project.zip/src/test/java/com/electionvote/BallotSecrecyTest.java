package com.electionvote;

import com.electionvote.model.Ballot;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import jakarta.persistence.EntityManager;
import jakarta.persistence.metamodel.EntityType;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
public class BallotSecrecyTest {

    @Autowired
    private EntityManager entityManager;

    @Test
    public void testBallotVoterUnlinkability() {
        EntityType<Ballot> ballotType = entityManager.getMetamodel().entity(Ballot.class);
        
        // Assert that Ballot model metadata contains NO attribute named 'voter'
        boolean hasVoterAttribute = ballotType.getAttributes().stream()
                .anyMatch(attr -> attr.getName().equalsIgnoreCase("voter"));
        
        assertFalse(hasVoterAttribute, "Ballot table must not contain a voter foreign key or reference, ensuring ballot secrecy.");
    }
}
