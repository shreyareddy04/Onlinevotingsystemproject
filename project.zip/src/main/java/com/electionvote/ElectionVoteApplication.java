package com.electionvote;

import com.electionvote.model.Candidate;
import com.electionvote.model.Election;
import com.electionvote.model.Voter;
import com.electionvote.repository.CandidateRepository;
import com.electionvote.repository.ElectionRepository;
import com.electionvote.repository.VoterRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.time.LocalDateTime;

@SpringBootApplication
public class ElectionVoteApplication {

    public static void main(String[] args) {
        SpringApplication.run(ElectionVoteApplication.class, args);
    }

    @Bean
    public CommandLineRunner initDemoData(VoterRepository voterRepository,
                                           ElectionRepository electionRepository,
                                           CandidateRepository candidateRepository,
                                           PasswordEncoder passwordEncoder) {
        return args -> {
            if (voterRepository.count() == 0) {
                // Initialize default Admin and Voter accounts
                Voter admin = new Voter("admin", "admin@electionvote.com", passwordEncoder.encode("AdminPass123!"), "System Administrator", "ADM-001", "ROLE_ADMIN");
                Voter voter1 = new Voter("voter1", "voter1@electionvote.com", passwordEncoder.encode("VoterPass123!"), "Alex Johnson", "ABC1234567", "ROLE_VOTER");
                voterRepository.save(admin);
                voterRepository.save(voter1);

                // Clearly labelled Demo Election
                Election demoElection = new Election(
                        "Demo Election - Student Council Leadership 2026",
                        "Official demo election for institutional testing and demonstration.",
                        "Demo Campus",
                        "OPEN",
                        LocalDateTime.now().minusDays(1),
                        LocalDateTime.now().plusDays(30)
                );
                electionRepository.save(demoElection);

                Candidate c1 = new Candidate("Candidate A", "Student Voice Party", "President", "Platform focused on campus facility access and library hours.", null, demoElection);
                Candidate c2 = new Candidate("Candidate B", "Campus Unity", "President", "Platform focused on student health resources and academic support.", null, demoElection);
                candidateRepository.save(c1);
                candidateRepository.save(c2);
            }

            voterRepository.findByUsername("voter1")
                    .filter(voter -> "VOT-101".equals(voter.getNationalId()))
                    .ifPresent(voter -> {
                        voter.setNationalId("ABC1234567");
                        voterRepository.save(voter);
                    });

            voterRepository.replacePlaceholderDistricts();
            candidateRepository.replacePlaceholderDistricts();
        };
    }
}
