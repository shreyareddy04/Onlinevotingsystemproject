package com.electionvote.service;

import com.electionvote.dto.BallotSubmissionDto;
import com.electionvote.model.*;
import com.electionvote.repository.*;
import org.apache.commons.codec.digest.DigestUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.UUID;

@Service
public class VotingService {

    private final BallotRepository ballotRepository;
    private final VoteReceiptRepository voteReceiptRepository;
    private final EligibilityRecordRepository eligibilityRecordRepository;
    private final ElectionRepository electionRepository;
    private final CandidateRepository candidateRepository;

    public VotingService(BallotRepository ballotRepository,
                         VoteReceiptRepository voteReceiptRepository,
                         EligibilityRecordRepository eligibilityRecordRepository,
                         ElectionRepository electionRepository,
                         CandidateRepository candidateRepository) {
        this.ballotRepository = ballotRepository;
        this.voteReceiptRepository = voteReceiptRepository;
        this.eligibilityRecordRepository = eligibilityRecordRepository;
        this.electionRepository = electionRepository;
        this.candidateRepository = candidateRepository;
    }

    public boolean isEligibleToVote(Voter voter, Election election) {
        return eligibilityRecordRepository.findByVoterAndElection(voter, election)
                .map(EligibilityRecord::isEligible)
                .orElse(true);
    }

    public boolean hasAlreadyVoted(Voter voter, Election election) {
        return eligibilityRecordRepository.findByVoterAndElection(voter, election)
                .map(EligibilityRecord::isHasVoted)
                .orElse(false);
    }

    @Transactional
    public VoteReceipt castVote(Voter voter, BallotSubmissionDto submission) {
        if (!"ROLE_VOTER".equals(voter.getRole())) {
            throw new IllegalStateException("Only voter accounts may cast a ballot");
        }
        Election election = electionRepository.findById(submission.getElectionId())
                .orElseThrow(() -> new IllegalArgumentException("Election not found"));

        if (!"OPEN".equalsIgnoreCase(election.getStatus()) && !"ACTIVE".equalsIgnoreCase(election.getStatus())) {
            throw new IllegalStateException("Voting is closed for this election");
        }

        Candidate candidate = candidateRepository.findById(submission.getCandidateId())
                .orElseThrow(() -> new IllegalArgumentException("Candidate not found"));
        if (!candidate.isApproved()) {
            throw new IllegalArgumentException("Selected candidate is not approved for this election");
        }
        if (!election.getId().equals(candidate.getElection().getId())) {
            throw new IllegalArgumentException("Selected candidate does not belong to this election");
        }
        if (!candidate.isAvailableToConstituency(voter.getConstituency())) {
            throw new IllegalArgumentException("Selected candidate is outside your constituency");
        }

        EligibilityRecord record = eligibilityRecordRepository.findByVoterAndElectionForUpdate(voter, election)
                .orElseGet(() -> eligibilityRecordRepository.saveAndFlush(
                        new EligibilityRecord(voter, election, true, false)));

        if (!record.isEligible()) {
            throw new IllegalStateException("Voter is not eligible to vote in this election");
        }

        if (record.isHasVoted()) {
            throw new IllegalStateException("Voter has already cast a ballot in this election");
        }

        String rawReceiptData = voter.getId() + ":" + election.getId() + ":" + candidate.getId() + ":" + System.currentTimeMillis();
        String receiptCode = "REC-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();
        String hash = DigestUtils.sha256Hex(rawReceiptData);

        // Anonymous Ballot Entry (No voter reference stored in ballot box)
        Ballot ballot = new Ballot(election, candidate, submission.getSelectedOptionsJson(), hash);
        ballotRepository.save(ballot);

        // Update Voter Participation Record
        record.setHasVoted(true);
        eligibilityRecordRepository.save(record);

        // Issue Receipt to Voter
        VoteReceipt receipt = new VoteReceipt(receiptCode, voter, election, candidate.getName(), hash);
        return voteReceiptRepository.save(receipt);
    }

    public List<VoteReceipt> getVoterReceipts(Voter voter) {
        return voteReceiptRepository.findByVoter(voter);
    }

    public VoteReceipt getReceiptByCode(String code) {
        return voteReceiptRepository.findByReceiptCode(code)
                .orElseThrow(() -> new IllegalArgumentException("Receipt code not found"));
    }
}
