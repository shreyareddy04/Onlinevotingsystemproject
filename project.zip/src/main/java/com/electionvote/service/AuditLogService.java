package com.electionvote.service;

import com.electionvote.model.AuditLog;
import com.electionvote.repository.AuditLogRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class AuditLogService {

    private final AuditLogRepository auditLogRepository;

    public AuditLogService(AuditLogRepository auditLogRepository) {
        this.auditLogRepository = auditLogRepository;
    }

    @Transactional
    public void logAction(String actorUsername, String action, String targetEntity, String ipAddress) {
        AuditLog log = new AuditLog(actorUsername, action, targetEntity, ipAddress);
        auditLogRepository.save(log);
    }

    public List<AuditLog> findAllLogs() {
        return auditLogRepository.findAll();
    }
}
