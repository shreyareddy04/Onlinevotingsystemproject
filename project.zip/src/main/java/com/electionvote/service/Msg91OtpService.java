package com.electionvote.service;

import com.fasterxml.jackson.databind.JsonNode;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClient;
import org.springframework.web.util.UriComponentsBuilder;

import java.net.URI;

@Service
public class Msg91OtpService {

    private static final String INDIA_CALLING_CODE = "91";

    private final RestClient restClient;
    private final String authKey;
    private final String templateId;
    private final String baseUrl;

    public Msg91OtpService(
            RestClient.Builder restClientBuilder,
            @Value("${msg91.auth-key:}") String authKey,
            @Value("${msg91.otp.template-id:}") String templateId,
            @Value("${msg91.otp.base-url:https://control.msg91.com/api/v5/otp}") String baseUrl) {
        this.restClient = restClientBuilder.build();
        this.authKey = authKey;
        this.templateId = templateId;
        this.baseUrl = baseUrl;
    }

    public void sendOtp(String indianMobileNumber) {
        requireConfiguration();
        URI uri = UriComponentsBuilder.fromUriString(baseUrl)
                .queryParam("authkey", authKey)
                .queryParam("template_id", templateId)
                .queryParam("mobile", toInternationalNumber(indianMobileNumber))
                .queryParam("otp_expiry", 5)
                .queryParam("otp_length", 6)
                .build()
                .encode()
                .toUri();
        JsonNode response = restClient.post()
                .uri(uri)
                .contentType(MediaType.APPLICATION_JSON)
                .retrieve()
                .body(JsonNode.class);
        requireSuccess(response, "MSG91 could not send the verification code.");
    }

    public boolean verifyOtp(String indianMobileNumber, String otp) {
        requireConfiguration();
        URI uri = UriComponentsBuilder.fromUriString(baseUrl + "/verify")
                .queryParam("mobile", toInternationalNumber(indianMobileNumber))
                .queryParam("otp", otp)
                .build()
                .encode()
                .toUri();
        JsonNode response = restClient.get()
                .uri(uri)
                .header("authkey", authKey)
                .retrieve()
                .body(JsonNode.class);
        return response != null && "success".equalsIgnoreCase(response.path("type").asText());
    }

    private void requireConfiguration() {
        if (authKey.isBlank() || templateId.isBlank()) {
            throw new IllegalStateException("MSG91 OTP is not configured. Set MSG91_AUTH_KEY and MSG91_OTP_TEMPLATE_ID.");
        }
    }

    private static String toInternationalNumber(String mobileNumber) {
        String digits = mobileNumber.replaceAll("\\D", "");
        if (digits.length() != 10 || !digits.matches("[6-9][0-9]{9}")) {
            throw new IllegalArgumentException("A valid registered Indian mobile number is required.");
        }
        return INDIA_CALLING_CODE + digits;
    }

    private static void requireSuccess(JsonNode response, String errorMessage) {
        if (response == null || !"success".equalsIgnoreCase(response.path("type").asText())) {
            throw new IllegalStateException(errorMessage);
        }
    }
}
