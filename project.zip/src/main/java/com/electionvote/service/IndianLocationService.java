package com.electionvote.service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

@Service
public class IndianLocationService {

    private final Map<String, Set<String>> districtsByState;

    public IndianLocationService(ObjectMapper objectMapper) {
        try (var input = new ClassPathResource("static/data/india-states-districts.json").getInputStream()) {
            List<StateDistricts> locations = objectMapper.readValue(input, new TypeReference<>() {});
            districtsByState = locations.stream().collect(Collectors.toUnmodifiableMap(
                    StateDistricts::state,
                    location -> Set.copyOf(location.districts())
            ));
        } catch (IOException e) {
            throw new IllegalStateException("Could not load the Indian state and district directory.", e);
        }
    }

    public String normalizeDistrictAndState(String value) {
        if (value == null || value.isBlank()) {
            throw new IllegalArgumentException("Select a district and state.");
        }
        int separator = value.lastIndexOf(',');
        if (separator <= 0 || separator == value.length() - 1) {
            throw new IllegalArgumentException("Select a valid Indian district and state.");
        }

        String district = value.substring(0, separator).trim();
        String state = value.substring(separator + 1).trim();
        Set<String> districts = districtsByState.get(state);
        if (districts == null || !districts.contains(district)) {
            throw new IllegalArgumentException("Select a valid Indian district and state.");
        }
        return district + ", " + state;
    }

    private record StateDistricts(String state, List<String> districts) {}
}
