package com.electionvote.service;

import com.electionvote.dto.ElectionResultsSnapshot;
import com.electionvote.model.Candidate;
import com.electionvote.model.Election;
import com.electionvote.repository.BallotRepository;
import com.electionvote.repository.CandidateRepository;
import com.electionvote.repository.ElectionRepository;
import org.springframework.stereotype.Service;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@Service
public class ResultsService {

    private final ElectionRepository electionRepository;
    private final CandidateRepository candidateRepository;
    private final BallotRepository ballotRepository;

    public ResultsService(ElectionRepository electionRepository,
                          CandidateRepository candidateRepository,
                          BallotRepository ballotRepository) {
        this.electionRepository = electionRepository;
        this.candidateRepository = candidateRepository;
        this.ballotRepository = ballotRepository;
    }

    public Map<Candidate, Long> getElectionResults(Long electionId) {
        Election election = electionRepository.findById(electionId)
                .orElseThrow(() -> new IllegalArgumentException("Election not found"));
        List<Candidate> candidates = candidateRepository.findByElection(election).stream()
                .sorted(java.util.Comparator.comparing(Candidate::getId))
                .toList();

        Map<Candidate, Long> result = new LinkedHashMap<>();
        for (Candidate candidate : candidates) {
            long votes = ballotRepository.countByElectionIdAndCandidateId(electionId, candidate.getId());
            result.put(candidate, votes);
        }
        return result;
    }

    public long getTotalVotesCast(Long electionId) {
        return ballotRepository.countByElectionId(electionId);
    }

    public ElectionResultsSnapshot getElectionResultsSnapshot(Long electionId) {
        List<ElectionResultsSnapshot.CandidateTally> tallies = getElectionResults(electionId).entrySet().stream()
                .map(entry -> new ElectionResultsSnapshot.CandidateTally(
                        entry.getKey().getId(),
                        entry.getKey().getName(),
                        entry.getKey().getParty(),
                        entry.getValue()))
                .toList();
        return new ElectionResultsSnapshot(getTotalVotesCast(electionId), tallies);
    }
}
