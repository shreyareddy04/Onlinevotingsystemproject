package com.electionvote.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import jakarta.servlet.http.HttpServletRequest;
import java.security.SecureRandom;
import java.util.Locale;

@Service
public class LocalOtpService {

    private static final SecureRandom RANDOM = new SecureRandom();

    private final boolean enabled;

    public LocalOtpService(@Value("${demo.otp-fallback-enabled:false}") boolean enabled) {
        this.enabled = enabled;
    }

    public boolean isEnabled() {
        return enabled;
    }

    public boolean isEnabledForLocalRequest(HttpServletRequest request) {
        if (!enabled || hasProxyHeaders(request)) return false;
        String host = request.getServerName();
        return "localhost".equalsIgnoreCase(host)
                || "127.0.0.1".equals(host)
                || "::1".equals(host)
                || "[::1]".equals(host);
    }

    public String generateOtp() {
        return String.format(Locale.ROOT, "%06d", RANDOM.nextInt(1_000_000));
    }

    private static boolean hasProxyHeaders(HttpServletRequest request) {
        return request.getHeader("Forwarded") != null
                || request.getHeader("X-Forwarded-Host") != null
                || request.getHeader("X-Forwarded-Proto") != null
                || request.getHeader("X-Original-Host") != null;
    }
}
