package com.electionvote.service;

import com.electionvote.dto.AdminRegistrationRequest;
import com.electionvote.dto.RegistrationRequest;
import com.electionvote.model.Voter;
import com.electionvote.repository.VoterRepository;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import javax.imageio.ImageIO;
import javax.imageio.ImageReader;
import javax.imageio.stream.ImageInputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Locale;
import java.util.Optional;
import java.util.UUID;
import java.util.Iterator;

@Service
public class VoterService {

    private final VoterRepository voterRepository;
    private final PasswordEncoder passwordEncoder;
    private final IndianLocationService indianLocationService;

    public VoterService(VoterRepository voterRepository, PasswordEncoder passwordEncoder,
                        IndianLocationService indianLocationService) {
        this.voterRepository = voterRepository;
        this.passwordEncoder = passwordEncoder;
        this.indianLocationService = indianLocationService;
    }

    @Transactional
    public Voter registerVoter(RegistrationRequest request) {
        validateVoterIdDocuments(request.getVoterIdFront(), request.getVoterIdBack());
        String nationalId = normalizeNationalId(request.getNationalId());
        if (findByNationalId(nationalId).isPresent()) {
            throw new IllegalArgumentException("Voter ID is already registered");
        }
        String mobileNumber = normalizeIndianMobileNumber(request.getMobileNumber());
        String constituency = indianLocationService.normalizeDistrictAndState(request.getConstituency());
        String accountId = UUID.randomUUID().toString();

        Voter voter = new Voter(
                "voter-" + accountId,
                accountId + "@voter.local.invalid",
                passwordEncoder.encode(UUID.randomUUID().toString()),
                "Registered Voter",
                nationalId,
                mobileNumber,
                constituency,
                "ROLE_VOTER"
        );
        voterRepository.save(voter);
        try {
            storeVoterIdDocuments(voter, request.getVoterIdFront(), request.getVoterIdBack());
            return voter;
        } catch (RuntimeException e) {
            deleteVoterIdImage(voter.getVoterIdFrontPath(), e);
            deleteVoterIdImage(voter.getVoterIdBackPath(), e);
            voterRepository.delete(voter);
            throw e;
        }
    }

    public static String normalizeIndianMobileNumber(String mobileNumber) {
        if (mobileNumber == null || mobileNumber.isBlank()) {
            throw new IllegalArgumentException("Enter your 10-digit Indian mobile number.");
        }
        String normalized = mobileNumber.trim().replaceAll("[\\s()-]", "");
        if (normalized.startsWith("+91")) {
            normalized = normalized.substring(3);
        } else if (normalized.startsWith("91") && normalized.length() == 12) {
            normalized = normalized.substring(2);
        }
        if (!normalized.matches("[6-9][0-9]{9}")) {
            throw new IllegalArgumentException("Enter a valid 10-digit Indian mobile number starting with 6, 7, 8, or 9.");
        }
        return normalized;
    }

    @Transactional
    public void storeVoterIdDocuments(Voter voter, MultipartFile front, MultipartFile back) {
        validateVoterIdDocuments(front, back);
        String frontExtension = validateImage(front);
        String backExtension = validateImage(back);
        String frontPath = saveVoterIdImage(front, "front", frontExtension);
        String backPath;
        try {
            backPath = saveVoterIdImage(back, "back", backExtension);
        } catch (RuntimeException e) {
            try {
                Files.deleteIfExists(Path.of(frontPath));
            } catch (IOException cleanupError) {
                e.addSuppressed(cleanupError);
            }
            throw e;
        }
        voter.setVoterIdFrontPath(frontPath);
        voter.setVoterIdBackPath(backPath);
        voterRepository.save(voter);
    }

    public void validateVoterIdDocuments(MultipartFile front, MultipartFile back) {
        validateImage(front);
        validateImage(back);
    }

    @Transactional
    public Voter registerAdmin(AdminRegistrationRequest request) {
        String email = normalizeEmail(request.getEmail());
        if (voterRepository.existsByUsername(email)) {
            throw new IllegalArgumentException("An account already uses this email as its username");
        }
        if (voterRepository.existsByEmailIgnoreCase(email)) {
            throw new IllegalArgumentException("Email is already registered");
        }

        Voter admin = new Voter(
                email,
                email,
                passwordEncoder.encode(request.getPassword()),
                "Administrator",
                "ADM-" + UUID.randomUUID().toString().substring(0, 6).toUpperCase(),
                "0000000000",
                "System Central",
                "ROLE_ADMIN"
        );
        return voterRepository.save(admin);
    }

    private String saveVoterIdImage(MultipartFile file, String side, String extension) {
        Path uploadDirectory = Path.of("./data/private/voter_ids").toAbsolutePath().normalize();
        Path destination = uploadDirectory.resolve(UUID.randomUUID() + "_" + side + extension).normalize();
        if (!destination.startsWith(uploadDirectory)) {
            throw new IllegalArgumentException("Invalid voter ID image destination");
        }
        try {
            Files.createDirectories(uploadDirectory);
            file.transferTo(destination);
            return destination.toString();
        } catch (IOException e) {
            throw new IllegalStateException("Could not store voter ID image", e);
        }
    }

    private static void deleteVoterIdImage(String imagePath, RuntimeException failure) {
        if (imagePath == null) {
            return;
        }
        try {
            Files.deleteIfExists(Path.of(imagePath));
        } catch (IOException cleanupError) {
            failure.addSuppressed(cleanupError);
        }
    }

    private String validateImage(MultipartFile file) {
        if (file == null || file.isEmpty()) {
            throw new IllegalArgumentException("Upload both the front and back of your voter ID");
        }
        if (file.getSize() > 5 * 1024 * 1024) {
            throw new IllegalArgumentException("Each voter ID image must be 5 MB or smaller");
        }
        try (var input = file.getInputStream();
             ImageInputStream imageStream = ImageIO.createImageInputStream(input)) {
            if (imageStream == null) {
                throw new IllegalArgumentException("Voter ID uploads must be JPEG or PNG images");
            }
            Iterator<ImageReader> readers = ImageIO.getImageReaders(imageStream);
            if (!readers.hasNext()) {
                throw new IllegalArgumentException("Voter ID uploads must be valid JPEG or PNG images");
            }
            ImageReader reader = readers.next();
            try {
                reader.setInput(imageStream, true, true);
                String format = reader.getFormatName();
                String extension = switch (format.toLowerCase()) {
                    case "jpeg", "jpg" -> ".jpg";
                    case "png" -> ".png";
                    default -> throw new IllegalArgumentException("Voter ID uploads must be JPEG or PNG images");
                };
                int width = reader.getWidth(0);
                int height = reader.getHeight(0);
                if (width <= 0 || height <= 0 || width > 5000 || height > 5000
                        || (long) width * height > 12_000_000) {
                    throw new IllegalArgumentException("Voter ID image dimensions are too large");
                }
                if (reader.read(0) == null) {
                    throw new IllegalArgumentException("Voter ID upload is not a valid image");
                }
                return extension;
            } finally {
                reader.dispose();
            }
        } catch (IOException e) {
            throw new IllegalArgumentException("Could not read voter ID image", e);
        }
    }

    public Optional<Voter> findByUsername(String username) {
        return voterRepository.findByUsername(username);
    }

    @Transactional
    public Voter updateConstituency(String username, String constituency) {
        Voter voter = findByUsername(username)
                .orElseThrow(() -> new IllegalArgumentException("Voter account not found"));
        voter.setConstituency(indianLocationService.normalizeDistrictAndState(constituency));
        return voterRepository.save(voter);
    }

    public Optional<Voter> findByEmail(String email) {
        if (email == null || email.isBlank()) {
            return Optional.empty();
        }
        return voterRepository.findByEmailIgnoreCase(normalizeEmail(email));
    }

    public Optional<Voter> findByNationalId(String nationalId) {
        if (nationalId == null || nationalId.isBlank()) {
            return Optional.empty();
        }
        String normalized = normalizeNationalId(nationalId);
        return voterRepository.findByNationalIdIgnoreCase(normalized)
                .or(() -> voterRepository.findAll().stream()
                        .filter(voter -> voter.getNationalId() != null)
                        .filter(voter -> hasNationalId(voter, normalized))
                        .findFirst());
    }

    private static boolean hasNationalId(Voter voter, String normalizedNationalId) {
        try {
            return normalizeNationalId(voter.getNationalId()).equals(normalizedNationalId);
        } catch (IllegalArgumentException e) {
            return false;
        }
    }

    public static String normalizeNationalId(String nationalId) {
        if (nationalId == null || nationalId.isBlank()) {
            throw new IllegalArgumentException("Enter your voter ID number.");
        }
        String normalized = nationalId.replaceAll("[\\s-]+", "").toUpperCase(Locale.ROOT);
        if (!normalized.matches("[A-Z0-9]+")) {
            throw new IllegalArgumentException("Voter ID numbers may contain only letters, numbers, spaces, and hyphens.");
        }
        return normalized;
    }

    private static String normalizeEmail(String email) {
        if (email == null || email.isBlank()) {
            throw new IllegalArgumentException("Enter an email address.");
        }
        return email.trim().toLowerCase(Locale.ROOT);
    }

    public Optional<Voter> findById(Long id) {
        return voterRepository.findById(id);
    }

    public List<Voter> findAllVoters() {
        return voterRepository.findAll();
    }

    @Transactional
    public Voter save(Voter voter) {
        return voterRepository.save(voter);
    }
}
