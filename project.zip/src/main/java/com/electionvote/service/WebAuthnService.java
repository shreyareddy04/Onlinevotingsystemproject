package com.electionvote.service;

import com.electionvote.model.PasskeyCredential;
import com.electionvote.model.Voter;
import com.electionvote.repository.PasskeyCredentialRepository;
import com.electionvote.repository.VoterRepository;
import com.yubico.webauthn.AssertionRequest;
import com.yubico.webauthn.FinishAssertionOptions;
import com.yubico.webauthn.FinishRegistrationOptions;
import com.yubico.webauthn.RelyingParty;
import com.yubico.webauthn.StartAssertionOptions;
import com.yubico.webauthn.StartRegistrationOptions;
import com.yubico.webauthn.data.AuthenticatorSelectionCriteria;
import com.yubico.webauthn.data.ByteArray;
import com.yubico.webauthn.data.PublicKeyCredential;
import com.yubico.webauthn.data.PublicKeyCredentialCreationOptions;
import com.yubico.webauthn.data.UserIdentity;
import com.yubico.webauthn.data.UserVerificationRequirement;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

@Service
public class WebAuthnService {

    private static final long CHALLENGE_TTL_SECONDS = 120;

    private final PasskeyCredentialRepository passkeyCredentialRepository;
    private final VoterRepository voterRepository;
    private final RelyingParty relyingParty;
    private final Map<String, PendingRegistration> pendingRegistrations = new ConcurrentHashMap<>();
    private final Map<String, PendingAssertion> pendingAssertions = new ConcurrentHashMap<>();

    private record PendingRegistration(String username, PublicKeyCredentialCreationOptions options, Instant expiresAt) {}
    private record PendingAssertion(String username, AssertionRequest request, Instant expiresAt) {}

    public WebAuthnService(PasskeyCredentialRepository passkeyCredentialRepository,
                           VoterRepository voterRepository,
                           RelyingParty relyingParty) {
        this.passkeyCredentialRepository = passkeyCredentialRepository;
        this.voterRepository = voterRepository;
        this.relyingParty = relyingParty;
    }

    public String generateRegistrationOptions(Voter voter) {
        if (voter.getId() == null) {
            throw new IllegalStateException("Voter account must be saved before registering a passkey");
        }
        UserIdentity user = UserIdentity.builder()
                .name(voter.getUsername())
                .displayName(voter.getFullName())
                .id(userHandle(voter.getId()))
                .build();
        PublicKeyCredentialCreationOptions options = relyingParty.startRegistration(
                StartRegistrationOptions.builder()
                        .user(user)
                        .authenticatorSelection(AuthenticatorSelectionCriteria.builder()
                                .userVerification(UserVerificationRequirement.REQUIRED)
                                .build())
                        .build());
        String challenge = options.getChallenge().getBase64Url();
        pendingRegistrations.put(challenge, new PendingRegistration(
                voter.getUsername(), options, Instant.now().plusSeconds(CHALLENGE_TTL_SECONDS)));
        return toCredentialsCreateJson(options);
    }

    @Transactional
    public PasskeyCredential finishRegistration(String username, String challenge, String credentialJson) {
        PendingRegistration pending = pendingRegistrations.remove(challenge);
        if (pending == null || pending.expiresAt().isBefore(Instant.now())
                || !pending.username().equals(username)) {
            throw new IllegalArgumentException("Passkey registration challenge is invalid or expired");
        }
        try {
            PublicKeyCredential<com.yubico.webauthn.data.AuthenticatorAttestationResponse,
                    com.yubico.webauthn.data.ClientRegistrationExtensionOutputs> response =
                    PublicKeyCredential.parseRegistrationResponseJson(credentialJson);
            var result = relyingParty.finishRegistration(FinishRegistrationOptions.builder()
                    .request(pending.options())
                    .response(response)
                    .build());
            if (!result.isUserVerified()) {
                throw new IllegalArgumentException("The authenticator did not verify the voter");
            }

            Voter voter = voterRepository.findByUsername(username)
                    .orElseThrow(() -> new IllegalStateException("Voter account not found"));
            PasskeyCredential credential = new PasskeyCredential(
                    result.getKeyId().getId().getBase64Url(),
                    result.getPublicKeyCose().getBase64Url(),
                    result.getSignatureCount(),
                    userHandle(voter.getId()).getBase64Url(),
                    voter);
            return passkeyCredentialRepository.save(credential);
        } catch (IOException e) {
            throw new IllegalArgumentException("Invalid passkey registration response", e);
        } catch (com.yubico.webauthn.exception.RegistrationFailedException e) {
            throw new IllegalArgumentException("Passkey registration could not be verified", e);
        }
    }

    public String generateAssertionOptions(String username) {
        if (passkeyCredentialRepository.findByVoter_Username(username).stream()
                .noneMatch(WebAuthnService::isUsableCredential)) {
            throw new IllegalStateException("Register a passkey before verifying your identity");
        }
        AssertionRequest request = relyingParty.startAssertion(StartAssertionOptions.builder()
                .username(username)
                .userVerification(UserVerificationRequirement.REQUIRED)
                .build());
        String challenge = request.getPublicKeyCredentialRequestOptions().getChallenge().getBase64Url();
        pendingAssertions.put(challenge, new PendingAssertion(
                username, request, Instant.now().plusSeconds(CHALLENGE_TTL_SECONDS)));
        return toCredentialsGetJson(request);
    }

    @Transactional
    public void verifyAssertion(String username, String challenge, String credentialJson) {
        PendingAssertion pending = pendingAssertions.remove(challenge);
        if (pending == null || pending.expiresAt().isBefore(Instant.now())
                || !pending.username().equals(username)) {
            throw new IllegalArgumentException("Passkey verification challenge is invalid or expired");
        }
        try {
            PublicKeyCredential<com.yubico.webauthn.data.AuthenticatorAssertionResponse,
                    com.yubico.webauthn.data.ClientAssertionExtensionOutputs> response =
                    PublicKeyCredential.parseAssertionResponseJson(credentialJson);
            var result = relyingParty.finishAssertion(FinishAssertionOptions.builder()
                    .request(pending.request())
                    .response(response)
                    .build());
            if (!result.isSuccess() || !result.isUserVerified()
                    || !username.equals(result.getUsername())) {
                throw new IllegalArgumentException("Passkey verification failed");
            }
            PasskeyCredential saved = passkeyCredentialRepository.findByCredentialId(
                            result.getCredential().getCredentialId().getBase64Url())
                    .orElseThrow(() -> new IllegalArgumentException("Passkey is not registered to this voter"));
            saved.setSignatureCount(result.getSignatureCount());
            passkeyCredentialRepository.save(saved);
        } catch (IOException e) {
            throw new IllegalArgumentException("Invalid passkey assertion response", e);
        } catch (com.yubico.webauthn.exception.AssertionFailedException e) {
            throw new IllegalArgumentException("Passkey assertion could not be verified", e);
        }
    }

    public boolean hasPasskey(String username) {
        return passkeyCredentialRepository.findByVoter_Username(username).stream()
                .anyMatch(WebAuthnService::isUsableCredential);
    }

    private static ByteArray userHandle(long voterId) {
        byte[] seed = ("votesphere-voter:" + voterId).getBytes(StandardCharsets.UTF_8);
        UUID id = UUID.nameUUIDFromBytes(seed);
        return new ByteArray(ByteBuffer.allocate(16)
                .putLong(id.getMostSignificantBits())
                .putLong(id.getLeastSignificantBits())
                .array());
    }

    private static boolean isUsableCredential(PasskeyCredential credential) {
        if (credential.getPublicKey() == null || credential.getPublicKey().startsWith("MOCK")) {
            return false;
        }
        try {
            ByteArray.fromBase64Url(credential.getCredentialId());
            ByteArray.fromBase64Url(credential.getUserHandle());
            ByteArray.fromBase64Url(credential.getPublicKey());
            return true;
        } catch (com.yubico.webauthn.data.exception.Base64UrlException e) {
            return false;
        }
    }

    private static String toCredentialsCreateJson(PublicKeyCredentialCreationOptions options) {
        try {
            return options.toCredentialsCreateJson();
        } catch (IOException e) {
            throw new IllegalStateException("Could not create passkey registration options", e);
        }
    }

    private static String toCredentialsGetJson(AssertionRequest request) {
        try {
            return request.toCredentialsGetJson();
        } catch (IOException e) {
            throw new IllegalStateException("Could not create passkey verification options", e);
        }
    }
}
