package com.electionvote.service;

import com.electionvote.model.Candidate;
import com.electionvote.model.Election;
import com.electionvote.repository.CandidateRepository;
import com.electionvote.repository.ElectionRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
public class ElectionService {

    private final ElectionRepository electionRepository;
    private final CandidateRepository candidateRepository;

    public ElectionService(ElectionRepository electionRepository, CandidateRepository candidateRepository) {
        this.electionRepository = electionRepository;
        this.candidateRepository = candidateRepository;
    }

    public List<Election> findAllElections() {
        return electionRepository.findAll();
    }

    public List<Election> findByStatus(String status) {
        return electionRepository.findByStatus(status);
    }

    public Optional<Election> findById(Long id) {
        return electionRepository.findById(id);
    }

    @Transactional
    public Election saveElection(Election election) {
        return electionRepository.save(election);
    }

    public List<Candidate> findCandidatesByElectionId(Long electionId) {
        return candidateRepository.findByElectionId(electionId);
    }

    public List<Candidate> findApprovedCandidatesByElectionId(Long electionId) {
        return findCandidatesByElectionId(electionId).stream()
                .filter(Candidate::isApproved)
                .toList();
    }

    public Optional<Candidate> findCandidateById(Long candidateId) {
        return candidateRepository.findById(candidateId);
    }

    @Transactional
    public Candidate saveCandidate(Candidate candidate) {
        return candidateRepository.save(candidate);
    }

    @Transactional
    public void deleteElection(Long id) {
        electionRepository.deleteById(id);
    }
}
