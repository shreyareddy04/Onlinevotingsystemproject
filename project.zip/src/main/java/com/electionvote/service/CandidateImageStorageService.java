package com.electionvote.service;

import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import javax.imageio.ImageIO;
import javax.imageio.ImageReader;
import javax.imageio.stream.ImageInputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Iterator;
import java.util.Locale;
import java.util.UUID;

@Service
public class CandidateImageStorageService {
    private static final long MAX_IMAGE_SIZE = 5L * 1024 * 1024;
    private static final Path IMAGE_DIRECTORY = Path.of("./data/candidate-images").toAbsolutePath().normalize();

    public String store(MultipartFile image, String imageDescription) {
        if (image == null || image.isEmpty()) return null;
        if (image.getSize() > MAX_IMAGE_SIZE) {
            throw new IllegalArgumentException(imageDescription + " must be 5 MB or smaller.");
        }
        String extension = validateImage(image, imageDescription);
        String filename = UUID.randomUUID() + extension;
        Path destination = IMAGE_DIRECTORY.resolve(filename).normalize();
        if (!destination.startsWith(IMAGE_DIRECTORY)) {
            throw new IllegalArgumentException("Invalid " + imageDescription.toLowerCase(Locale.ROOT) + " destination.");
        }
        try {
            Files.createDirectories(IMAGE_DIRECTORY);
            image.transferTo(destination);
            return "/candidate-images/" + filename;
        } catch (IOException e) {
            throw new IllegalStateException("Could not store " + imageDescription.toLowerCase(Locale.ROOT) + ".", e);
        }
    }

    private static String validateImage(MultipartFile image, String imageDescription) {
        try (var input = image.getInputStream();
             ImageInputStream imageStream = ImageIO.createImageInputStream(input)) {
            if (imageStream == null) {
                throw new IllegalArgumentException(imageDescription + " must be a JPEG or PNG image.");
            }
            Iterator<ImageReader> readers = ImageIO.getImageReaders(imageStream);
            if (!readers.hasNext()) {
                throw new IllegalArgumentException(imageDescription + " must be a valid JPEG or PNG image.");
            }
            ImageReader reader = readers.next();
            try {
                reader.setInput(imageStream, true, true);
                String extension = switch (reader.getFormatName().toLowerCase(Locale.ROOT)) {
                    case "jpeg", "jpg" -> ".jpg";
                    case "png" -> ".png";
                    default -> throw new IllegalArgumentException(imageDescription + " must be a JPEG or PNG image.");
                };
                int width = reader.getWidth(0);
                int height = reader.getHeight(0);
                if (width <= 0 || height <= 0 || width > 5000 || height > 5000
                        || (long) width * height > 12_000_000 || reader.read(0) == null) {
                    throw new IllegalArgumentException(imageDescription + " is invalid or has dimensions that are too large.");
                }
                return extension;
            } finally {
                reader.dispose();
            }
        } catch (IOException e) {
            throw new IllegalArgumentException("Could not read " + imageDescription.toLowerCase(Locale.ROOT) + ".", e);
        }
    }
}
