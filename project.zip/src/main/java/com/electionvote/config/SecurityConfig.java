package com.electionvote.config;

import com.electionvote.model.Voter;
import com.electionvote.repository.VoterRepository;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.logout.SecurityContextLogoutHandler;

import java.util.Collections;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    public UserDetailsService userDetailsService(VoterRepository voterRepository) {
        return username -> {
            Voter voter = voterRepository.findByUsername(username)
                    .or(() -> voterRepository.findByEmailIgnoreCase(username.trim()))
                    .orElseThrow(() -> new UsernameNotFoundException("User not found: " + username));
            return new User(
                    voter.getUsername(),
                    voter.getPassword(),
                    voter.isEnabled(),
                    true, true, true,
                    Collections.singletonList(new SimpleGrantedAuthority(voter.getRole()))
            );
        };
    }

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http
            .csrf(csrf -> csrf.ignoringRequestMatchers("/api/webauthn/**", "/h2-console/**"))
            .headers(headers -> headers.frameOptions(frame -> frame.disable())) // For H2 console
            .authorizeHttpRequests(auth -> auth
                .requestMatchers("/", "/elections", "/how-it-works", "/help", "/contact", "/voter-login",
                                 "/privacy", "/terms", "/register", "/login", "/confirmation",
                                 "/admin/register", "/candidate/register", "/candidate-images/**",
                                 "/data/india-states-districts.json",
                                 "/css/**", "/js/**", "/vendor/**", "/bootstrap/**",
                                 "/favicon.svg", "/favicon.ico", "/h2-console/**").permitAll()
                .requestMatchers("/admin/**").hasRole("ADMIN")
                .requestMatchers("/candidate/**").hasRole("VOTER")
                .requestMatchers("/api/webauthn/**", "/ballot/**", "/my-votes", "/account").hasRole("VOTER")
                .anyRequest().authenticated()
            )
            .formLogin(form -> form
                .loginPage("/login")
                .loginProcessingUrl("/login")
                .failureUrl("/?error")
                .successHandler((request, response, authentication) -> {
                    boolean administrator = authentication.getAuthorities().stream()
                            .anyMatch(authority -> "ROLE_ADMIN".equals(authority.getAuthority()));
                    if (administrator) {
                        response.sendRedirect("/admin/dashboard");
                    } else {
                        new SecurityContextLogoutHandler().logout(request, response, authentication);
                        response.sendRedirect("/?error");
                    }
                })
                .permitAll()
            )
            .logout(logout -> logout
                .logoutUrl("/logout")
                .logoutSuccessUrl("/login?logout")
                .permitAll()
            );

        return http.build();
    }
}
