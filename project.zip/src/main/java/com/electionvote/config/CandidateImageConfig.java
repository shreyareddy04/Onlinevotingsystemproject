package com.electionvote.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import java.nio.file.Path;

@Configuration
public class CandidateImageConfig implements WebMvcConfigurer {
    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        Path imageDirectory = Path.of("./data/candidate-images").toAbsolutePath().normalize();
        registry.addResourceHandler("/candidate-images/**")
                .addResourceLocations(imageDirectory.toUri().toString());
    }
}
