package com.electionvote.config;

import com.yubico.webauthn.CredentialRepository;
import com.yubico.webauthn.RegisteredCredential;
import com.yubico.webauthn.RelyingParty;
import com.yubico.webauthn.data.ByteArray;
import com.yubico.webauthn.data.PublicKeyCredentialDescriptor;
import com.yubico.webauthn.data.RelyingPartyIdentity;
import com.electionvote.model.PasskeyCredential;
import com.electionvote.repository.PasskeyCredentialRepository;
import com.electionvote.repository.VoterRepository;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;

@Configuration
public class WebAuthnConfig {

    @Value("${webauthn.hostname:localhost}")
    private String hostname;

    @Value("${webauthn.display-name:Election Vote Platform}")
    private String displayName;

    @Value("${webauthn.origin:http://localhost:8080}")
    private String origin;

    @Bean
    public RelyingPartyIdentity relyingPartyIdentity() {
        return RelyingPartyIdentity.builder()
                .id(hostname)
                .name(displayName)
                .build();
    }

    @Bean
    public CredentialRepository credentialRepository(PasskeyCredentialRepository credentials,
                                                       VoterRepository voters) {
        return new DatabaseCredentialRepository(credentials, voters);
    }

    @Bean
    public RelyingParty relyingParty(RelyingPartyIdentity rpIdentity, CredentialRepository credentialRepository) {
        return RelyingParty.builder()
                .identity(rpIdentity)
                .credentialRepository(credentialRepository)
                .origins(Set.of(origin))
                .build();
    }

    private static ByteArray userHandle(long voterId) {
        byte[] seed = ("votesphere-voter:" + voterId).getBytes(StandardCharsets.UTF_8);
        UUID id = UUID.nameUUIDFromBytes(seed);
        return new ByteArray(ByteBuffer.allocate(16)
                .putLong(id.getMostSignificantBits())
                .putLong(id.getLeastSignificantBits())
                .array());
    }

    private static class DatabaseCredentialRepository implements CredentialRepository {
        private final PasskeyCredentialRepository credentials;
        private final VoterRepository voters;

        private DatabaseCredentialRepository(PasskeyCredentialRepository credentials, VoterRepository voters) {
            this.credentials = credentials;
            this.voters = voters;
        }

        @Override
        public Set<PublicKeyCredentialDescriptor> getCredentialIdsForUsername(String username) {
            return credentials.findByVoter_Username(username).stream()
                    .filter(DatabaseCredentialRepository::isUsable)
                    .map(credential -> PublicKeyCredentialDescriptor.builder()
                            .id(decode(credential.getCredentialId()))
                            .build())
                    .collect(java.util.stream.Collectors.toSet());
        }

        @Override
        public Optional<String> getUsernameForUserHandle(ByteArray userHandle) {
            return credentials.findByUserHandle(userHandle.getBase64Url()).stream()
                    .map(credential -> credential.getVoter().getUsername())
                    .findFirst();
        }

        @Override
        public Optional<ByteArray> getUserHandleForUsername(String username) {
            return voters.findByUsername(username).map(voter -> userHandle(voter.getId()));
        }

        @Override
        public Optional<RegisteredCredential> lookup(ByteArray credentialId, ByteArray userHandle) {
            return credentials.findByCredentialId(credentialId.getBase64Url())
                    .filter(DatabaseCredentialRepository::isUsable)
                    .filter(credential -> userHandle.getBase64Url().equals(credential.getUserHandle()))
                    .map(DatabaseCredentialRepository::toRegisteredCredential);
        }

        @Override
        public Set<RegisteredCredential> lookupAll(ByteArray credentialId) {
            return credentials.findByCredentialId(credentialId.getBase64Url()).stream()
                    .filter(DatabaseCredentialRepository::isUsable)
                    .map(DatabaseCredentialRepository::toRegisteredCredential)
                    .collect(java.util.stream.Collectors.toSet());
        }

        private static RegisteredCredential toRegisteredCredential(PasskeyCredential credential) {
            return RegisteredCredential.builder()
                    .credentialId(decode(credential.getCredentialId()))
                    .userHandle(decode(credential.getUserHandle()))
                    .publicKeyCose(decode(credential.getPublicKey()))
                    .signatureCount(credential.getSignatureCount())
                    .build();
        }

        private static boolean isUsable(PasskeyCredential credential) {
            if (credential.getPublicKey() == null || credential.getPublicKey().startsWith("MOCK")) {
                return false;
            }
            try {
                decode(credential.getCredentialId());
                decode(credential.getUserHandle());
                decode(credential.getPublicKey());
                return true;
            } catch (IllegalStateException e) {
                return false;
            }
        }

        private static ByteArray decode(String value) {
            try {
                return ByteArray.fromBase64Url(value);
            } catch (com.yubico.webauthn.data.exception.Base64UrlException e) {
                throw new IllegalStateException("Stored passkey data is invalid", e);
            }
        }
    }
}
