package com.electionvote.repository;

import com.electionvote.model.Candidate;
import com.electionvote.model.Election;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Repository
public interface CandidateRepository extends JpaRepository<Candidate, Long> {
    List<Candidate> findByElection(Election election);
    List<Candidate> findByElectionId(Long electionId);

    @Modifying
    @Transactional
    @Query("""
            update Candidate c
            set c.constituency = 'Hyderabad, Telangana'
            where lower(c.constituency) in
                ('central district', 'north district', 'south district', 'east district', 'west district')
            """)
    int replacePlaceholderDistricts();
}
