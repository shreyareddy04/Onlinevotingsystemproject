package com.electionvote.repository;

import com.electionvote.model.Voter;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;

@Repository
public interface VoterRepository extends JpaRepository<Voter, Long> {
    Optional<Voter> findByUsername(String username);
    Optional<Voter> findByEmail(String email);
    Optional<Voter> findByEmailIgnoreCase(String email);
    Optional<Voter> findByNationalIdIgnoreCase(String nationalId);
    boolean existsByUsername(String username);
    boolean existsByEmail(String email);
    boolean existsByEmailIgnoreCase(String email);

    @Modifying
    @Transactional
    @Query("""
            update Voter v
            set v.constituency = 'Hyderabad, Telangana'
            where lower(v.constituency) in
                ('central district', 'north district', 'south district', 'east district', 'west district')
            """)
    int replacePlaceholderDistricts();
}
