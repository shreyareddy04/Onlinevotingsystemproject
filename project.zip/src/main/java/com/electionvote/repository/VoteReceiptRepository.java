package com.electionvote.repository;

import com.electionvote.model.Voter;
import com.electionvote.model.VoteReceipt;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface VoteReceiptRepository extends JpaRepository<VoteReceipt, Long> {
    Optional<VoteReceipt> findByReceiptCode(String receiptCode);
    List<VoteReceipt> findByVoter(Voter voter);
    List<VoteReceipt> findByVoterId(Long voterId);
}
