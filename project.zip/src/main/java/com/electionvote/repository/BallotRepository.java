package com.electionvote.repository;

import com.electionvote.model.Ballot;
import com.electionvote.model.Election;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface BallotRepository extends JpaRepository<Ballot, Long> {
    List<Ballot> findByElection(Election election);
    List<Ballot> findByElectionId(Long electionId);
    long countByCandidateId(Long candidateId);
    long countByElectionId(Long electionId);
    long countByElectionIdAndCandidateId(Long electionId, Long candidateId);
}
