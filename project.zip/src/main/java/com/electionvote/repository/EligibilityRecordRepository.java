package com.electionvote.repository;

import com.electionvote.model.EligibilityRecord;
import com.electionvote.model.Election;
import com.electionvote.model.Voter;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;
import jakarta.persistence.LockModeType;

@Repository
public interface EligibilityRecordRepository extends JpaRepository<EligibilityRecord, Long> {
    Optional<EligibilityRecord> findByVoterAndElection(Voter voter, Election election);
    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("select record from EligibilityRecord record where record.voter = :voter and record.election = :election")
    Optional<EligibilityRecord> findByVoterAndElectionForUpdate(@Param("voter") Voter voter,
                                                                 @Param("election") Election election);
    Optional<EligibilityRecord> findByVoterIdAndElectionId(Long voterId, Long electionId);
    List<EligibilityRecord> findByVoter(Voter voter);
    List<EligibilityRecord> findByElection(Election election);
}
