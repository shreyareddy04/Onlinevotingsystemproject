package com.electionvote.repository;

import com.electionvote.model.PasskeyCredential;
import com.electionvote.model.Voter;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface PasskeyCredentialRepository extends JpaRepository<PasskeyCredential, Long> {
    Optional<PasskeyCredential> findByCredentialId(String credentialId);
    List<PasskeyCredential> findByVoter(Voter voter);
    List<PasskeyCredential> findByVoterId(Long voterId);
    @EntityGraph(attributePaths = "voter")
    List<PasskeyCredential> findByVoter_Username(String username);
    @EntityGraph(attributePaths = "voter")
    List<PasskeyCredential> findByUserHandle(String userHandle);
}
