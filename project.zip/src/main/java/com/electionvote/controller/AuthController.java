package com.electionvote.controller;

import com.electionvote.dto.AdminRegistrationRequest;
import com.electionvote.dto.RegistrationRequest;
import com.electionvote.model.Voter;
import com.electionvote.service.VoterService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.web.context.HttpSessionSecurityContextRepository;
import org.springframework.security.web.context.SecurityContextRepository;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class AuthController {

    private final VoterService voterService;
    private final SecurityContextRepository securityContextRepository =
            new HttpSessionSecurityContextRepository();

    public AuthController(VoterService voterService) {
        this.voterService = voterService;
    }

    @GetMapping("/login")
    public String login(@RequestParam(value = "error", required = false) String error,
                        @RequestParam(value = "logout", required = false) String logout,
                        @RequestParam(value = "registered", required = false) String registered,
                        Model model) {
        if (error != null) {
            model.addAttribute("errorMessage", "Invalid username or password.");
        }
        if (logout != null) {
            model.addAttribute("successMessage", "You have been logged out successfully.");
        }
        if (registered != null) {
            model.addAttribute("successMessage", "admin".equals(registered)
                    ? "Administrator account created. Log in with your email and password."
                    : "Voter account created. Enter your voter ID to continue.");
        }
        model.addAttribute("adminLoginOpen", error != null || registered != null);
        return "index";
    }

    @PostMapping("/voter-login")
    public String voterLogin(@RequestParam String voterId,
                             @RequestParam MultipartFile voterIdFront,
                             @RequestParam MultipartFile voterIdBack,
                             HttpServletRequest request,
                             HttpServletResponse response,
                             RedirectAttributes redirectAttributes) {
        String normalizedVoterId;
        try {
            normalizedVoterId = VoterService.normalizeNationalId(voterId);
        } catch (IllegalArgumentException e) {
            redirectAttributes.addFlashAttribute("voterErrorMessage",
                    e.getMessage());
            return "redirect:/";
        }

        Voter voter = voterService.findByNationalId(normalizedVoterId)
                .filter(candidate -> "ROLE_VOTER".equals(candidate.getRole()) && candidate.isEnabled())
                .orElse(null);
        if (voter == null) {
            redirectAttributes.addFlashAttribute("voterErrorMessage",
                    "That ID is not registered in this local demo yet. Create a voter account with this ID first. Uploaded photos are not checked against an official voter registry.");
            return "redirect:/";
        }

        try {
            voterService.storeVoterIdDocuments(voter, voterIdFront, voterIdBack);
        } catch (IllegalArgumentException e) {
            redirectAttributes.addFlashAttribute("voterErrorMessage", e.getMessage());
            return "redirect:/";
        } catch (IllegalStateException e) {
            redirectAttributes.addFlashAttribute("voterErrorMessage",
                    "We could not save the ID photos. Please try again.");
            return "redirect:/";
        }

        authenticateVoter(voter, request, response);
        request.getSession().setAttribute("voter_id_verified_demo", true);

        redirectAttributes.addFlashAttribute("identityVerifiedMessage",
                "Your voter ID number matched a voter record in this local demo. Choose an election to continue.");
        return "redirect:/elections";
    }

    // Voter Registration
    @GetMapping("/register")
    public String registerForm(Model model) {
        model.addAttribute("registrationRequest", new RegistrationRequest());
        return "register";
    }

    @PostMapping("/register")
    public String registerVoter(@ModelAttribute RegistrationRequest registrationRequest,
                                HttpServletRequest request,
                                HttpServletResponse response,
                                Model model) {
        try {
            Voter voter = voterService.registerVoter(registrationRequest);
            authenticateVoter(voter, request, response);
            request.getSession().setAttribute("passkey_registration_pending", true);
            return "redirect:/register/passkey";
        } catch (IllegalArgumentException e) {
            model.addAttribute("errorMessage", e.getMessage());
            model.addAttribute("registrationRequest", registrationRequest);
            return "register";
        } catch (IllegalStateException e) {
            model.addAttribute("errorMessage", "We could not save your voter ID photos. Please try again.");
            model.addAttribute("registrationRequest", registrationRequest);
            return "register";
        }
    }

    @GetMapping("/register/passkey")
    public String registerPasskeyPage(HttpSession session) {
        if (!Boolean.TRUE.equals(session.getAttribute("passkey_registration_pending"))) {
            return "redirect:/";
        }
        return "register-passkey";
    }

    private void authenticateVoter(Voter voter, HttpServletRequest request, HttpServletResponse response) {
        request.getSession(true);
        request.changeSessionId();
        var principal = User.withUsername(voter.getUsername())
                .password("")
                .authorities(new SimpleGrantedAuthority(voter.getRole()))
                .build();
        var authentication = new UsernamePasswordAuthenticationToken(
                principal, null, principal.getAuthorities());
        SecurityContext context = SecurityContextHolder.createEmptyContext();
        context.setAuthentication(authentication);
        SecurityContextHolder.setContext(context);
        securityContextRepository.saveContext(context, request, response);
    }

    // Admin Registration
    @GetMapping("/admin/register")
    public String adminRegisterForm(Model model) {
        model.addAttribute("adminRegistrationRequest", new AdminRegistrationRequest());
        return "admin/register";
    }

    @PostMapping("/admin/register")
    public String registerAdmin(@ModelAttribute AdminRegistrationRequest request,
                                Model model,
                                RedirectAttributes redirectAttributes) {
        model.addAttribute("adminRegistrationRequest", request);
        if (request.getPassword() == null || request.getPassword().isBlank()) {
            model.addAttribute("errorMessage", "Enter a password.");
            return "admin/register";
        }
        if (!request.getPassword().equals(request.getConfirmPassword())) {
            model.addAttribute("errorMessage", "The passwords do not match. Re-enter them and try again.");
            return "admin/register";
        }
        try {
            voterService.registerAdmin(request);
            redirectAttributes.addFlashAttribute("successMessage",
                    "Administrator account created. Log in with your email and password.");
            return "redirect:/login?registered=admin";
        } catch (IllegalArgumentException e) {
            model.addAttribute("errorMessage", e.getMessage());
            return "admin/register";
        }
    }
}
