package com.electionvote.controller;

import com.electionvote.dto.ElectionResultsSnapshot;
import com.electionvote.model.Candidate;
import com.electionvote.model.Election;
import com.electionvote.service.AuditLogService;
import com.electionvote.dto.CandidateRegistrationForm;
import com.electionvote.service.CandidateImageStorageService;
import com.electionvote.service.ElectionService;
import com.electionvote.service.IndianLocationService;
import com.electionvote.service.ResultsService;
import com.electionvote.service.VoterService;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.http.MediaType;

import java.util.List;

@Controller
@RequestMapping("/admin")
public class AdminController {

    private final ElectionService electionService;
    private final VoterService voterService;
    private final AuditLogService auditLogService;
    private final CandidateImageStorageService imageStorageService;
    private final ResultsService resultsService;
    private final IndianLocationService indianLocationService;

    public AdminController(ElectionService electionService, VoterService voterService,
                           AuditLogService auditLogService, CandidateImageStorageService imageStorageService,
                           ResultsService resultsService, IndianLocationService indianLocationService) {
        this.electionService = electionService;
        this.voterService = voterService;
        this.auditLogService = auditLogService;
        this.imageStorageService = imageStorageService;
        this.resultsService = resultsService;
        this.indianLocationService = indianLocationService;
    }

    @GetMapping("/dashboard")
    public String dashboard(Model model) {
        model.addAttribute("elections", electionService.findAllElections());
        model.addAttribute("voters", voterService.findAllVoters());
        model.addAttribute("auditLogs", auditLogService.findAllLogs());
        return "admin/dashboard";
    }

    @GetMapping("/elections/{electionId}/results")
    public String electionResults(@PathVariable Long electionId, Model model) {
        Election election = electionService.findById(electionId)
                .orElseThrow(() -> new IllegalArgumentException("Invalid election ID: " + electionId));
        model.addAttribute("election", election);
        model.addAttribute("results", resultsService.getElectionResults(electionId));
        model.addAttribute("totalVotes", resultsService.getTotalVotesCast(electionId));
        model.addAttribute("adminView", true);
        return "results";
    }

    @GetMapping(value = "/elections/{electionId}/results/data", produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public ElectionResultsSnapshot electionResultsData(@PathVariable Long electionId) {
        electionService.findById(electionId)
                .orElseThrow(() -> new IllegalArgumentException("Invalid election ID: " + electionId));
        return resultsService.getElectionResultsSnapshot(electionId);
    }

    @GetMapping("/election/new")
    public String newElectionForm(Model model) {
        model.addAttribute("election", new Election());
        return "admin/election-form";
    }

    @PostMapping("/election/save")
    public String saveElection(@ModelAttribute Election election,
                               @AuthenticationPrincipal UserDetails userDetails,
                               HttpServletRequest request) {
        Election saved = electionService.saveElection(election);
        auditLogService.logAction(
                userDetails.getUsername(),
                "SAVE_ELECTION",
                "Election ID: " + saved.getId() + " (" + saved.getTitle() + ")",
                request.getRemoteAddr()
        );
        return "redirect:/admin/dashboard";
    }

    @PostMapping("/election/{id}/toggle-status")
    public String toggleStatus(@PathVariable Long id,
                               @RequestParam String status,
                               @AuthenticationPrincipal UserDetails userDetails,
                               HttpServletRequest request) {
        Election election = electionService.findById(id).orElseThrow();
        election.setStatus(status);
        electionService.saveElection(election);

        auditLogService.logAction(
                userDetails.getUsername(),
                "CHANGE_ELECTION_STATUS",
                "Election ID: " + id + " status set to " + status,
                request.getRemoteAddr()
        );
        return "redirect:/admin/dashboard";
    }

    @GetMapping("/candidates/{electionId}")
    public String manageCandidates(@PathVariable Long electionId,
                                   @RequestParam(value = "editId", required = false) Long editId,
                                   Model model) {
        Election election = electionService.findById(electionId).orElseThrow();
        List<Candidate> candidates = electionService.findCandidatesByElectionId(electionId);
        model.addAttribute("election", election);
        model.addAttribute("candidates", candidates);
        CandidateRegistrationForm candidateForm = new CandidateRegistrationForm();
        candidateForm.setElectionId(electionId);
        if (editId != null) {
            Candidate candidate = electionService.findCandidateById(editId)
                    .filter(existing -> electionId.equals(existing.getElection().getId()))
                    .orElseThrow();
            candidateForm.setCandidateId(candidate.getId());
            candidateForm.setName(candidate.getName());
            candidateForm.setParty(candidate.getParty());
            candidateForm.setPosition(candidate.getPosition());
            candidateForm.setConstituency(candidate.getConstituency());
            candidateForm.setBio(candidate.getBio());
            candidateForm.setApproved(candidate.isApproved());
            model.addAttribute("editingCandidate", candidate);
        }
        model.addAttribute("candidateForm", candidateForm);
        return "admin/candidates";
    }

    @PostMapping("/candidate/save")
    public String saveCandidate(@ModelAttribute("candidateForm") CandidateRegistrationForm form,
                                @AuthenticationPrincipal UserDetails userDetails,
                                HttpServletRequest request,
                                Model model) {
        Long electionId = form.getElectionId();
        try {
            CandidateRegistrationController.validateProfile(form, false, indianLocationService);
            Election election = electionService.findById(electionId).orElseThrow();
            Candidate candidate;
            boolean creating = form.getCandidateId() == null;
            if (creating) {
                candidate = new Candidate();
            } else {
                candidate = electionService.findCandidateById(form.getCandidateId())
                        .filter(existing -> electionId.equals(existing.getElection().getId()))
                        .orElseThrow(() -> new IllegalArgumentException("Candidate not found for this election."));
            }
            if ((creating || candidate.getPhotoUrl() == null || candidate.getPhotoUrl().isBlank())
                    && (form.getPhoto() == null || form.getPhoto().isEmpty())) {
                throw new IllegalArgumentException("Upload a candidate photo.");
            }
            if ((creating || candidate.getPartySymbolUrl() == null || candidate.getPartySymbolUrl().isBlank())
                    && (form.getPartySymbol() == null || form.getPartySymbol().isEmpty())) {
                throw new IllegalArgumentException("Upload the party symbol image.");
            }
            CandidateRegistrationController.applyProfile(candidate, form);
            candidate.setElection(election);
            if (form.getPhoto() != null && !form.getPhoto().isEmpty()) {
                candidate.setPhotoUrl(imageStorageService.store(form.getPhoto(), "Candidate photo"));
            }
            if (form.getPartySymbol() != null && !form.getPartySymbol().isEmpty()) {
                candidate.setPartySymbolUrl(imageStorageService.store(form.getPartySymbol(), "Party symbol"));
            }
            candidate.setApproved(Boolean.TRUE.equals(form.getApproved()));
            Candidate saved = electionService.saveCandidate(candidate);
            auditLogService.logAction(
                    userDetails.getUsername(),
                    creating ? "ADD_CANDIDATE" : "EDIT_CANDIDATE",
                    "Candidate: " + saved.getName() + " in Election ID: " + electionId
                            + "; approved=" + saved.isApproved(),
                    request.getRemoteAddr()
            );
        } catch (IllegalArgumentException | IllegalStateException e) {
            model.addAttribute("errorMessage", e.getMessage());
            model.addAttribute("election", electionService.findById(electionId).orElseThrow());
            model.addAttribute("candidates", electionService.findCandidatesByElectionId(electionId));
            model.addAttribute("candidateForm", form);
            if (form.getCandidateId() != null) {
                model.addAttribute("editingCandidate", electionService.findCandidateById(form.getCandidateId()).orElse(null));
            }
            return "admin/candidates";
        }
        return "redirect:/admin/candidates/" + electionId;
    }

    @GetMapping("/voters")
    public String manageVoters(Model model) {
        model.addAttribute("voters", voterService.findAllVoters());
        return "admin/voters";
    }
}
