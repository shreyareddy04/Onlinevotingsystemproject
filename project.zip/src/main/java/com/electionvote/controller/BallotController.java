package com.electionvote.controller;

import com.electionvote.dto.BallotSubmissionDto;
import com.electionvote.model.Candidate;
import com.electionvote.model.Election;
import com.electionvote.model.Voter;
import com.electionvote.service.ElectionService;
import com.electionvote.service.LocalOtpService;
import com.electionvote.service.Msg91OtpService;
import com.electionvote.service.VoterService;
import com.electionvote.service.VotingService;
import com.electionvote.service.WebAuthnService;
import jakarta.servlet.http.HttpSession;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.authentication.logout.SecurityContextLogoutHandler;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.time.Instant;
import java.util.List;
import java.util.stream.Collectors;

@Controller
public class BallotController {

    private static final String WORKFLOW_ELECTION_ID = "voting_election_id";
    private static final String CONFIRMATION_ELECTION_ID = "vote_confirmation_election_id";
    private static final String CONFIRMATION_CANDIDATE_ID = "vote_confirmation_candidate_id";
    private static final long OTP_TTL_SECONDS = 300;
    private static final int OTP_MAX_ATTEMPTS = 5;

    private final ElectionService electionService;
    private final VotingService votingService;
    private final VoterService voterService;
    private final WebAuthnService webAuthnService;
    private final Msg91OtpService msg91OtpService;
    private final LocalOtpService localOtpService;

    public BallotController(ElectionService electionService, VotingService votingService,
                            VoterService voterService, WebAuthnService webAuthnService,
                            Msg91OtpService msg91OtpService, LocalOtpService localOtpService) {
        this.electionService = electionService;
        this.votingService = votingService;
        this.voterService = voterService;
        this.webAuthnService = webAuthnService;
        this.msg91OtpService = msg91OtpService;
        this.localOtpService = localOtpService;
    }

    @GetMapping("/ballot/{electionId}")
    public String startVotingWizard(@PathVariable Long electionId, HttpSession session) {
        startWorkflow(session, electionId);
        int nextStep = Boolean.TRUE.equals(session.getAttribute("step1_verified")) ? 2 : 1;
        return "redirect:/ballot/wizard/" + electionId + "/step" + nextStep;
    }

    @GetMapping("/ballot/wizard/{electionId}/step1")
    public String step1VoterId(@PathVariable Long electionId,
                               @AuthenticationPrincipal UserDetails userDetails,
                               HttpSession session,
                               Model model) {
        if (!isCurrentWorkflow(session, electionId)) {
            startWorkflow(session, electionId);
        }
        Voter voter = getVoter(userDetails);
        Election election = getElection(electionId);
        model.addAttribute("alreadyVoted", votingService.hasAlreadyVoted(voter, election));
        model.addAttribute("voter", voter);
        model.addAttribute("election", election);
        model.addAttribute("step", 1);
        return "voter-verification";
    }

    @PostMapping("/ballot/wizard/{electionId}/step1")
    public String processStep1(@PathVariable Long electionId,
                               @RequestParam String voterId,
                               @RequestParam MultipartFile voterIdFront,
                               @RequestParam MultipartFile voterIdBack,
                               @AuthenticationPrincipal UserDetails userDetails,
                               HttpSession session,
                               RedirectAttributes redirectAttributes) {
        Voter voter = getVoter(userDetails);
        if (!isCurrentWorkflow(session, electionId)) {
            startWorkflow(session, electionId);
        }
        boolean voterIdMatches = false;
        if (voter.getNationalId() != null) {
            try {
                voterIdMatches = VoterService.normalizeNationalId(voter.getNationalId())
                        .equals(VoterService.normalizeNationalId(voterId));
            } catch (IllegalArgumentException ignored) {
                voterIdMatches = false;
            }
        }
        if (!voterIdMatches) {
            redirectAttributes.addFlashAttribute("errorMessage", "Voter ID does not match the ID on this account.");
            return stepUrl(electionId, 1);
        }
        try {
            voterService.storeVoterIdDocuments(voter, voterIdFront, voterIdBack);
        } catch (IllegalArgumentException e) {
            redirectAttributes.addFlashAttribute("errorMessage", e.getMessage());
            return stepUrl(electionId, 1);
        }
        session.setAttribute("step1_verified", true);
        return stepUrl(electionId, 2);
    }

    @GetMapping("/ballot/wizard/{electionId}/step2")
    public String step2Mobile(@PathVariable Long electionId,
                              @AuthenticationPrincipal UserDetails userDetails,
                              HttpSession session,
                              Model model) {
        String redirect = requireStep(session, electionId, 2);
        if (redirect != null) return redirect;
        model.addAttribute("voter", getVoter(userDetails));
        model.addAttribute("election", getElection(electionId));
        model.addAttribute("step", 2);
        return "voter-verification";
    }

    @PostMapping("/ballot/wizard/{electionId}/send-otp")
    public String sendOtp(@PathVariable Long electionId,
                          @RequestParam String mobileNumber,
                          @AuthenticationPrincipal UserDetails userDetails,
                          HttpServletRequest request,
                          HttpSession session,
                          RedirectAttributes redirectAttributes) {
        String redirect = requireStep(session, electionId, 2);
        if (redirect != null) return redirect;
        Voter voter = getVoter(userDetails);
        String registeredPhone;
        try {
            registeredPhone = VoterService.normalizeIndianMobileNumber(voter.getMobileNumber());
        } catch (IllegalArgumentException e) {
            redirectAttributes.addFlashAttribute("errorMessage",
                    "There is no valid mobile number on your voter account. Update your account before continuing.");
            return stepUrl(electionId, 2);
        }
        String submittedPhone;
        try {
            submittedPhone = VoterService.normalizeIndianMobileNumber(mobileNumber);
        } catch (IllegalArgumentException e) {
            redirectAttributes.addFlashAttribute("errorMessage",
                    "Enter the valid 10-digit mobile number you used when registering your voter ID.");
            return stepUrl(electionId, 2);
        }
        if (!registeredPhone.equals(submittedPhone)) {
            redirectAttributes.addFlashAttribute("errorMessage",
                    "The mobile number does not match the one saved with your voter registration.");
            return stepUrl(electionId, 2);
        }
        String localOtp = null;
        try {
            msg91OtpService.sendOtp(registeredPhone);
        } catch (IllegalStateException e) {
            if (!localOtpService.isEnabledForLocalRequest(request)) {
                redirectAttributes.addFlashAttribute("errorMessage", e.getMessage());
                return stepUrl(electionId, 2);
            }
            localOtp = localOtpService.generateOtp();
        } catch (org.springframework.web.client.RestClientException e) {
            if (!localOtpService.isEnabledForLocalRequest(request)) {
                redirectAttributes.addFlashAttribute("errorMessage",
                        "We could not send a code to your mobile right now. Please try again later.");
                return stepUrl(electionId, 2);
            }
            localOtp = localOtpService.generateOtp();
        }
        session.setAttribute("voting_otp_expiry", Instant.now().plusSeconds(OTP_TTL_SECONDS));
        session.setAttribute("voting_otp_attempts", 0);
        session.setAttribute("step2_verified", true);
        session.setAttribute("voting_otp_sent", localOtp == null);
        if (localOtp != null) {
            session.setAttribute("voting_local_otp", localOtp);
            redirectAttributes.addFlashAttribute("infoMessage",
                    "MSG91 is unavailable. A local demo code is shown on the next screen; no SMS was sent.");
        } else {
            session.removeAttribute("voting_local_otp");
        }
        return stepUrl(electionId, 3);
    }

    @GetMapping("/ballot/wizard/{electionId}/step3")
    public String step3Otp(@PathVariable Long electionId,
                           @AuthenticationPrincipal UserDetails userDetails,
                           HttpSession session,
                           Model model) {
        String redirect = requireStep(session, electionId, 3);
        if (redirect != null) return redirect;
        model.addAttribute("voter", getVoter(userDetails));
        model.addAttribute("election", getElection(electionId));
        model.addAttribute("otpSent", Boolean.TRUE.equals(session.getAttribute("voting_otp_sent")));
        model.addAttribute("localOtp", session.getAttribute("voting_local_otp"));
        model.addAttribute("mobileLastFour", lastFourDigits(getVoter(userDetails).getMobileNumber()));
        model.addAttribute("step", 3);
        return "voter-verification";
    }

    @PostMapping("/ballot/wizard/{electionId}/step3")
    public String processStep3(@PathVariable Long electionId,
                               @RequestParam String otpCode,
                               @AuthenticationPrincipal UserDetails userDetails,
                               HttpSession session,
                               RedirectAttributes redirectAttributes) {
        String redirect = requireStep(session, electionId, 3);
        if (redirect != null) return redirect;
        Instant expiry = (Instant) session.getAttribute("voting_otp_expiry");
        if (expiry == null || !expiry.isAfter(Instant.now())) {
            clearOtp(session);
            session.removeAttribute("step2_verified");
            redirectAttributes.addFlashAttribute("errorMessage", "Your code expired. Request a new OTP.");
            return stepUrl(electionId, 2);
        }

        Object attemptsValue = session.getAttribute("voting_otp_attempts");
        int attempts = attemptsValue instanceof Integer value ? value : 0;
        Voter voter = getVoter(userDetails);
        boolean verified;
        Object localOtp = session.getAttribute("voting_local_otp");
        if (localOtp instanceof String expectedOtp) {
            verified = otpCode.matches("\\d{6}") && expectedOtp.equals(otpCode);
        } else {
            try {
                verified = otpCode.matches("\\d{6}")
                        && msg91OtpService.verifyOtp(voter.getMobileNumber(), otpCode);
            } catch (org.springframework.web.client.RestClientException e) {
                redirectAttributes.addFlashAttribute("errorMessage",
                        "We could not verify your code right now. Please try again.");
                return stepUrl(electionId, 3);
            } catch (IllegalStateException e) {
                redirectAttributes.addFlashAttribute("errorMessage", e.getMessage());
                return stepUrl(electionId, 2);
            }
        }
        if (!verified) {
            attempts++;
            session.setAttribute("voting_otp_attempts", attempts);
            if (attempts >= OTP_MAX_ATTEMPTS) {
                clearOtp(session);
                session.removeAttribute("step2_verified");
                redirectAttributes.addFlashAttribute("errorMessage", "Too many incorrect codes. Request a new OTP.");
                return stepUrl(electionId, 2);
            }
            redirectAttributes.addFlashAttribute("errorMessage", "Enter the current six-digit verification code.");
            return stepUrl(electionId, 3);
        }
        session.setAttribute("step3_verified", true);
        session.removeAttribute("voting_otp_sent");
        session.removeAttribute("voting_otp_expiry");
        session.removeAttribute("voting_local_otp");
        return stepUrl(electionId, 4);
    }

    @GetMapping("/ballot/wizard/{electionId}/step4")
    public String step4Biometric(@PathVariable Long electionId,
                                 @AuthenticationPrincipal UserDetails userDetails,
                                 HttpSession session,
                                 Model model) {
        String redirect = requireStep(session, electionId, 4);
        if (redirect != null) return redirect;
        String username = userDetails.getUsername();
        model.addAttribute("voter", getVoter(userDetails));
        model.addAttribute("election", getElection(electionId));
        model.addAttribute("hasPasskey", webAuthnService.hasPasskey(username));
        model.addAttribute("step", 4);
        return "voter-verification";
    }

    @GetMapping("/ballot/wizard/{electionId}/step5")
    public String step5Candidates(@PathVariable Long electionId,
                                  @AuthenticationPrincipal UserDetails userDetails,
                                  HttpSession session,
                                  Model model) {
        String redirect = requireStep(session, electionId, 5);
        if (redirect != null) return redirect;
        session.removeAttribute(CONFIRMATION_ELECTION_ID);
        session.removeAttribute(CONFIRMATION_CANDIDATE_ID);
        Voter voter = getVoter(userDetails);
        Election election = getElection(electionId);

        List<Candidate> areaCandidates = electionService.findApprovedCandidatesByElectionId(electionId).stream()
                .filter(candidate -> !candidate.isNota())
                .filter(candidate -> candidate.isAvailableToConstituency(voter.getConstituency()))
                .collect(Collectors.toList());

        model.addAttribute("voter", voter);
        model.addAttribute("election", election);
        model.addAttribute("candidates", areaCandidates);
        model.addAttribute("step", 5);
        return "voter-verification";
    }

    @PostMapping("/ballot/confirm-vote")
    public String confirmVote(@RequestParam Long electionId,
                              @RequestParam Long candidateId,
                              @AuthenticationPrincipal UserDetails userDetails,
                              HttpSession session,
                              Model model,
                              RedirectAttributes redirectAttributes) {
        String redirect = requireStep(session, electionId, 5);
        if (redirect != null) return redirect;
        session.removeAttribute(CONFIRMATION_ELECTION_ID);
        session.removeAttribute(CONFIRMATION_CANDIDATE_ID);
        Voter voter = getVoter(userDetails);
        Election election = getElection(electionId);
        try {
            Candidate candidate = findSelectedCandidate(electionId, candidateId, voter);
            session.setAttribute(CONFIRMATION_ELECTION_ID, electionId);
            session.setAttribute(CONFIRMATION_CANDIDATE_ID, candidateId);
            model.addAttribute("election", election);
            model.addAttribute("candidate", candidate);
            model.addAttribute("notaSelected", candidateId == 0);
            model.addAttribute("voter", voter);
            return "review";
        } catch (IllegalArgumentException e) {
            redirectAttributes.addFlashAttribute("errorMessage", e.getMessage());
            return stepUrl(electionId, 5);
        }
    }

    @PostMapping("/ballot/final-confirmation")
    public String finalVoteConfirmation(@RequestParam Long electionId,
                                        @AuthenticationPrincipal UserDetails userDetails,
                                        HttpSession session,
                                        Model model,
                                        RedirectAttributes redirectAttributes) {
        String redirect = requireStep(session, electionId, 5);
        if (redirect != null) return redirect;
        Object selectedElectionId = session.getAttribute(CONFIRMATION_ELECTION_ID);
        Object selectedCandidateId = session.getAttribute(CONFIRMATION_CANDIDATE_ID);
        if (!electionId.equals(selectedElectionId) || !(selectedCandidateId instanceof Long candidateId)) {
            redirectAttributes.addFlashAttribute("errorMessage", "Review your selection before confirming your vote.");
            return stepUrl(electionId, 5);
        }

        Voter voter = getVoter(userDetails);
        Election election = getElection(electionId);
        Candidate candidate;
        try {
            candidate = findSelectedCandidate(electionId, candidateId, voter);
        } catch (IllegalArgumentException e) {
            session.removeAttribute(CONFIRMATION_ELECTION_ID);
            session.removeAttribute(CONFIRMATION_CANDIDATE_ID);
            redirectAttributes.addFlashAttribute("errorMessage", e.getMessage());
            return stepUrl(electionId, 5);
        }
        model.addAttribute("election", election);
        model.addAttribute("candidate", candidate);
        model.addAttribute("notaSelected", candidateId == 0);
        model.addAttribute("voter", voter);
        return "vote-confirmation";
    }

    @PostMapping("/ballot/cast-vote")
    public String castVoteAndLogout(@RequestParam Long electionId,
                                    @AuthenticationPrincipal UserDetails userDetails,
                                    HttpSession session,
                                    HttpServletRequest request,
                                    HttpServletResponse response,
                                    RedirectAttributes redirectAttributes) {
        String redirect = requireStep(session, electionId, 5);
        if (redirect != null) return redirect;
        Voter voter = getVoter(userDetails);
        Object selectedElectionId = session.getAttribute(CONFIRMATION_ELECTION_ID);
        Object selectedCandidateId = session.getAttribute(CONFIRMATION_CANDIDATE_ID);
        if (!electionId.equals(selectedElectionId) || !(selectedCandidateId instanceof Long candidateId)) {
            redirectAttributes.addFlashAttribute("errorMessage", "Review and confirm your ballot before casting it.");
            return stepUrl(electionId, 5);
        }

        try {
            Long finalCandidateId = candidateId;
            if (candidateId == 0) {
                Candidate notaCandidate = electionService.findCandidatesByElectionId(electionId).stream()
                        .filter(Candidate::isNota)
                        .findFirst()
                        .orElseGet(() -> electionService.saveCandidate(
                                new Candidate("NOTA - None of the Above", getElection(electionId), true)));
                finalCandidateId = notaCandidate.getId();
            }

            BallotSubmissionDto submission = new BallotSubmissionDto();
            submission.setElectionId(electionId);
            submission.setCandidateId(finalCandidateId);
            votingService.castVote(voter, submission);

            var authentication = SecurityContextHolder.getContext().getAuthentication();
            if (authentication != null) {
                new SecurityContextLogoutHandler().logout(request, response, authentication);
            }
            redirectAttributes.addFlashAttribute("successMessage", "Your vote has been successfully cast.");
            redirectAttributes.addFlashAttribute("voterName", voter.getFullName());
            redirectAttributes.addFlashAttribute("voterId", voter.getNationalId());
            return "redirect:/confirmation";
        } catch (IllegalArgumentException | IllegalStateException e) {
            session.removeAttribute(CONFIRMATION_ELECTION_ID);
            session.removeAttribute(CONFIRMATION_CANDIDATE_ID);
            redirectAttributes.addFlashAttribute("errorMessage", e.getMessage());
            return stepUrl(electionId, 5);
        }
    }

    @GetMapping("/confirmation")
    public String confirmation(Model model) {
        if (!model.containsAttribute("voterName") || !model.containsAttribute("voterId")) {
            return "redirect:/";
        }
        return "confirmation";
    }

    @GetMapping("/my-votes")
    public String myVotes(@AuthenticationPrincipal UserDetails userDetails, Model model) {
        Voter voter = getVoter(userDetails);
        model.addAttribute("receipts", votingService.getVoterReceipts(voter));
        return "my-votes";
    }

    private Voter getVoter(UserDetails userDetails) {
        if (userDetails == null) {
            throw new IllegalStateException("Sign in with a voter account to continue");
        }
        return voterService.findByUsername(userDetails.getUsername())
                .orElseThrow(() -> new IllegalArgumentException("Voter account not found"));
    }

    private Election getElection(Long electionId) {
        return electionService.findById(electionId)
                .orElseThrow(() -> new IllegalArgumentException("Election not found"));
    }

    private Candidate findSelectedCandidate(Long electionId, Long candidateId, Voter voter) {
        if (candidateId == 0) return null;
        Candidate candidate = electionService.findCandidateById(candidateId)
                .orElseThrow(() -> new IllegalArgumentException("Selected candidate not found"));
        if (!candidate.isApproved()
                || !electionId.equals(candidate.getElection().getId()) || candidate.isNota()) {
            throw new IllegalArgumentException("Select a candidate from this election.");
        }
        if (!candidate.isAvailableToConstituency(voter.getConstituency())) {
            throw new IllegalArgumentException("Selected candidate is outside your constituency.");
        }
        return candidate;
    }

    private static void startWorkflow(HttpSession session, Long electionId) {
        for (String key : List.of("step1_verified", "step2_verified", "step3_verified",
                "biometric_verified_election_id", "voting_otp_expiry", "voting_otp_sent",
                "voting_otp_attempts", "voting_local_otp", CONFIRMATION_ELECTION_ID,
                CONFIRMATION_CANDIDATE_ID)) {
            session.removeAttribute(key);
        }
        session.setAttribute(WORKFLOW_ELECTION_ID, electionId);
        if (Boolean.TRUE.equals(session.getAttribute("voter_id_verified_demo"))) {
            session.setAttribute("step1_verified", true);
        }
    }

    private static String requireStep(HttpSession session, Long electionId, int requiredStep) {
        if (!isCurrentWorkflow(session, electionId)) {
            return stepUrl(electionId, 1);
        }
        if (!Boolean.TRUE.equals(session.getAttribute("step1_verified"))) {
            return stepUrl(electionId, 1);
        }
        if (requiredStep >= 3 && !Boolean.TRUE.equals(session.getAttribute("step2_verified"))) {
            return stepUrl(electionId, 2);
        }
        if (requiredStep >= 4 && !Boolean.TRUE.equals(session.getAttribute("step3_verified"))) {
            return stepUrl(electionId, 3);
        }
        if (requiredStep >= 5 && !electionId.equals(session.getAttribute("biometric_verified_election_id"))) {
            return stepUrl(electionId, 4);
        }
        return null;
    }

    private static boolean isCurrentWorkflow(HttpSession session, Long electionId) {
        return electionId.equals(session.getAttribute(WORKFLOW_ELECTION_ID));
    }

    private static String stepUrl(Long electionId, int step) {
        return "redirect:/ballot/wizard/" + electionId + "/step" + step;
    }

    private static String normalizePhone(String value) {
        return value == null ? "" : value.replaceAll("\\D", "");
    }

    private static String lastFourDigits(String phoneNumber) {
        String digits = normalizePhone(phoneNumber);
        return digits.length() <= 4 ? digits : digits.substring(digits.length() - 4);
    }

    private static void clearOtp(HttpSession session) {
        session.removeAttribute("voting_otp_expiry");
        session.removeAttribute("voting_otp_sent");
        session.removeAttribute("voting_otp_attempts");
        session.removeAttribute("voting_local_otp");
    }
}
