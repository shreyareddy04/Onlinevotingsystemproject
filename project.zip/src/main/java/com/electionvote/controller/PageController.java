package com.electionvote.controller;

import com.electionvote.model.Voter;
import com.electionvote.service.VoterService;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class PageController {

    private final VoterService voterService;

    public PageController(VoterService voterService) {
        this.voterService = voterService;
    }

    @GetMapping("/")
    public String index(@RequestParam(value = "error", required = false) String error,
                        @RequestParam(value = "logout", required = false) String logout,
                        @RequestParam(value = "registered", required = false) String registered,
                        Model model) {
        if (error != null) {
            model.addAttribute("errorMessage", "Administrator login failed. Check your email and password.");
            model.addAttribute("adminLoginOpen", true);
        } else if (logout != null) {
            model.addAttribute("successMessage", "You have been signed out.");
        } else if (registered != null) {
            model.addAttribute("successMessage", "Registration completed. Sign in to continue.");
            model.addAttribute("adminLoginOpen", "admin".equals(registered));
        }
        return "index";
    }

    @GetMapping("/how-it-works")
    public String howItWorks() {
        return "how-it-works";
    }

    @GetMapping("/help")
    public String help() {
        return "help";
    }

    @GetMapping("/contact")
    public String contact() {
        return "contact";
    }

    @GetMapping("/privacy")
    public String privacy() {
        return "privacy";
    }

    @GetMapping("/terms")
    public String terms() {
        return "terms";
    }

    @GetMapping("/account")
    public String account(@AuthenticationPrincipal UserDetails userDetails, Model model) {
        if (userDetails != null) {
            Voter voter = voterService.findByUsername(userDetails.getUsername()).orElse(null);
            model.addAttribute("voter", voter);
        }
        return "account";
    }

    @PostMapping("/account/constituency")
    public String updateConstituency(@AuthenticationPrincipal UserDetails userDetails,
                                     @RequestParam String constituency,
                                     RedirectAttributes redirectAttributes) {
        try {
            voterService.updateConstituency(userDetails.getUsername(), constituency);
            redirectAttributes.addFlashAttribute("successMessage", "Your constituency was updated.");
        } catch (IllegalArgumentException e) {
            redirectAttributes.addFlashAttribute("errorMessage", e.getMessage());
        }
        return "redirect:/account";
    }
}
