package com.electionvote.controller;

import com.electionvote.dto.WebAuthnFinishRequest;
import com.electionvote.model.Voter;
import com.electionvote.service.VoterService;
import com.electionvote.service.WebAuthnService;
import jakarta.servlet.http.HttpSession;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/webauthn")
public class WebAuthnController {

    private final WebAuthnService webAuthnService;
    private final VoterService voterService;

    public WebAuthnController(WebAuthnService webAuthnService, VoterService voterService) {
        this.webAuthnService = webAuthnService;
        this.voterService = voterService;
    }

    @GetMapping(value = "/register/options", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> getRegisterOptions(@AuthenticationPrincipal UserDetails userDetails) {
        if (userDetails == null) {
            return ResponseEntity.status(401).body(Map.of("error", "Sign in before registering a passkey"));
        }
        Voter voter = voterService.findByUsername(userDetails.getUsername())
                .orElseThrow(() -> new IllegalArgumentException("Voter not found"));
        return ResponseEntity.ok().contentType(MediaType.APPLICATION_JSON)
                .body(webAuthnService.generateRegistrationOptions(voter));
    }

    @PostMapping("/register/finish")
    public ResponseEntity<?> finishRegistration(@AuthenticationPrincipal UserDetails userDetails,
                                                 @RequestBody WebAuthnFinishRequest request,
                                                 HttpSession session) {
        if (userDetails == null) {
            return ResponseEntity.status(401).body(Map.of("error", "Sign in before registering a passkey"));
        }
        if (request.getChallenge() == null || request.getCredentialJson() == null) {
            return ResponseEntity.badRequest().body(Map.of("error", "Passkey registration response is incomplete"));
        }
        webAuthnService.finishRegistration(
                userDetails.getUsername(), request.getChallenge(), request.getCredentialJson());
        session.removeAttribute("passkey_registration_pending");
        return ResponseEntity.ok(Map.of("status", "SUCCESS", "message", "Passkey registered and verified"));
    }

    @GetMapping(value = "/authenticate/options", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> getAuthenticateOptions(@AuthenticationPrincipal UserDetails userDetails,
                                                     HttpSession session) {
        if (userDetails == null) {
            return ResponseEntity.status(401).body(Map.of("error", "Sign in before verifying your passkey"));
        }
        if (!isReadyForBiometricStep(session)) {
            return ResponseEntity.status(403).body(Map.of("error", "Complete voter ID and OTP verification first"));
        }
        return ResponseEntity.ok().contentType(MediaType.APPLICATION_JSON)
                .body(webAuthnService.generateAssertionOptions(userDetails.getUsername()));
    }

    @PostMapping("/authenticate/finish")
    public ResponseEntity<?> finishAuthentication(@AuthenticationPrincipal UserDetails userDetails,
                                                   @RequestBody WebAuthnFinishRequest request,
                                                   HttpSession session) {
        if (userDetails == null) {
            return ResponseEntity.status(401).body(Map.of("error", "Sign in before verifying your passkey"));
        }
        if (!isReadyForBiometricStep(session)) {
            return ResponseEntity.status(403).body(Map.of("error", "Complete voter ID and OTP verification first"));
        }
        if (request.getChallenge() == null || request.getCredentialJson() == null) {
            return ResponseEntity.badRequest().body(Map.of("error", "Passkey verification response is incomplete"));
        }
        webAuthnService.verifyAssertion(
                userDetails.getUsername(), request.getChallenge(), request.getCredentialJson());
        session.setAttribute("biometric_verified_election_id", session.getAttribute("voting_election_id"));
        return ResponseEntity.ok(Map.of("status", "SUCCESS", "message", "Passkey verified"));
    }

    private static boolean isReadyForBiometricStep(HttpSession session) {
        return session.getAttribute("voting_election_id") instanceof Long
                && Boolean.TRUE.equals(session.getAttribute("step1_verified"))
                && Boolean.TRUE.equals(session.getAttribute("step2_verified"))
                && Boolean.TRUE.equals(session.getAttribute("step3_verified"));
    }
}
