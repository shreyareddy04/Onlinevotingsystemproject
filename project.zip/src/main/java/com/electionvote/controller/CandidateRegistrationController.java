package com.electionvote.controller;

import com.electionvote.dto.CandidateRegistrationForm;
import com.electionvote.model.Candidate;
import com.electionvote.model.Election;
import com.electionvote.service.CandidateImageStorageService;
import com.electionvote.service.ElectionService;
import com.electionvote.service.IndianLocationService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;
@Controller
public class CandidateRegistrationController {
    private final ElectionService electionService;
    private final CandidateImageStorageService imageStorageService;
    private final IndianLocationService indianLocationService;

    public CandidateRegistrationController(ElectionService electionService,
                                           CandidateImageStorageService imageStorageService,
                                           IndianLocationService indianLocationService) {
        this.electionService = electionService;
        this.imageStorageService = imageStorageService;
        this.indianLocationService = indianLocationService;
    }

    @GetMapping("/candidate/register")
    public String registrationForm(Model model) {
        model.addAttribute("candidateForm", new CandidateRegistrationForm());
        model.addAttribute("elections", nominationElections());
        return "candidate-registration";
    }

    @PostMapping("/candidate/register")
    public String registerCandidate(@ModelAttribute("candidateForm") CandidateRegistrationForm form,
                                    Model model) {
        List<Election> elections = nominationElections();
        try {
            validateProfile(form, true, indianLocationService);
            Election election = electionService.findById(form.getElectionId())
                    .filter(CandidateRegistrationController::acceptsNominations)
                    .orElseThrow(() -> new IllegalArgumentException(
                            "Choose an election that is still accepting candidate nominations."));

            Candidate candidate = new Candidate();
            applyProfile(candidate, form);
            candidate.setElection(election);
            candidate.setPhotoUrl(imageStorageService.store(form.getPhoto(), "Candidate photo"));
            candidate.setPartySymbolUrl(imageStorageService.store(form.getPartySymbol(), "Party symbol"));
            candidate.setApproved(false);
            electionService.saveCandidate(candidate);
            return "candidate-registration-submitted";
        } catch (IllegalArgumentException | IllegalStateException e) {
            model.addAttribute("errorMessage", e.getMessage());
            model.addAttribute("elections", elections);
            return "candidate-registration";
        }
    }

    private List<Election> nominationElections() {
        return electionService.findAllElections().stream()
                .filter(CandidateRegistrationController::acceptsNominations)
                .toList();
    }

    private static boolean acceptsNominations(Election election) {
        String status = election.getStatus();
        return status != null && status.equalsIgnoreCase("UPCOMING");
    }

    static void validateProfile(CandidateRegistrationForm form, boolean requireImages,
                                IndianLocationService indianLocationService) {
        requireText(form.getName(), "Enter the candidate's full name.");
        requireText(form.getParty(), "Enter the party name or Independent.");
        requireText(form.getPosition(), "Enter the position the candidate is contesting.");
        form.setConstituency(indianLocationService.normalizeDistrictAndState(form.getConstituency()));
        requireText(form.getBio(), "Enter the candidate's manifesto and key promises.");
        if (form.getElectionId() == null) {
            throw new IllegalArgumentException("Choose an election to register for.");
        }
        if (requireImages) {
            requireImage(form.getPhoto(), "Upload a candidate photo.");
            requireImage(form.getPartySymbol(), "Upload the party symbol image.");
        }
    }

    private static void requireText(String value, String message) {
        if (value == null || value.isBlank()) throw new IllegalArgumentException(message);
    }

    private static void requireImage(MultipartFile image, String message) {
        if (image == null || image.isEmpty()) throw new IllegalArgumentException(message);
    }

    static void applyProfile(Candidate candidate, CandidateRegistrationForm form) {
        candidate.setName(form.getName().trim());
        candidate.setParty(form.getParty().trim());
        candidate.setPosition(form.getPosition().trim());
        candidate.setConstituency(form.getConstituency().trim());
        candidate.setBio(form.getBio().trim());
    }
}
