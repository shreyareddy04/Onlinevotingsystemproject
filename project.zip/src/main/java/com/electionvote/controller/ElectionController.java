package com.electionvote.controller;

import com.electionvote.model.Candidate;
import com.electionvote.model.Election;
import com.electionvote.service.ElectionService;
import com.electionvote.service.ResultsService;
import com.electionvote.service.VoterService;
import jakarta.servlet.http.HttpSession;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;
import java.util.Map;

@Controller
public class ElectionController {

    private final ElectionService electionService;
    private final ResultsService resultsService;
    private final VoterService voterService;

    public ElectionController(ElectionService electionService, ResultsService resultsService, VoterService voterService) {
        this.electionService = electionService;
        this.resultsService = resultsService;
        this.voterService = voterService;
    }

    @GetMapping("/elections")
    public String elections(@RequestParam(value = "status", required = false) String status,
                            Model model) {
        List<Election> elections;
        if (status != null && !status.isBlank()) {
            elections = electionService.findByStatus(status.toUpperCase());
            model.addAttribute("selectedStatus", status);
        } else {
            elections = electionService.findAllElections();
        }
        model.addAttribute("elections", elections);
        model.addAttribute("identityVerified", model.containsAttribute("identityVerifiedMessage"));
        return "elections";
    }

    @GetMapping("/elections/{id}")
    public String electionDetail(@PathVariable Long id, Model model) {
        Election election = electionService.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Invalid election ID: " + id));
        model.addAttribute("election", election);
        return "election-detail";
    }

    @GetMapping("/candidate/{id}")
    public String candidateDetail(@PathVariable Long id,
                                  @AuthenticationPrincipal UserDetails userDetails,
                                  HttpSession session,
                                  Model model) {
        Candidate candidate = electionService.findCandidateById(id)
                .orElseThrow(() -> new IllegalArgumentException("Invalid candidate ID: " + id));
        Long electionId = candidate.getElection().getId();
        if (userDetails == null
                || !electionId.equals(session.getAttribute("biometric_verified_election_id"))) {
            return "redirect:/ballot/" + electionId;
        }
        var voter = voterService.findByUsername(userDetails.getUsername())
                .orElseThrow(() -> new IllegalArgumentException("Voter account not found"));
        String constituency = candidate.getConstituency();
        if (!candidate.isApproved() || candidate.isNota()
                || (constituency != null && !constituency.isBlank()
                && !"All".equalsIgnoreCase(constituency)
                && !constituency.equalsIgnoreCase(voter.getConstituency()))) {
            return "redirect:/ballot/wizard/" + electionId + "/step5";
        }
        model.addAttribute("candidate", candidate);
        return "candidate";
    }

    @GetMapping("/results/{id}")
    public String electionResults(@PathVariable Long id, Model model, RedirectAttributes redirectAttributes) {
        Election election = electionService.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Invalid election ID: " + id));

        // Enforce rule: Results are hidden until election is closed
        if ("OPEN".equalsIgnoreCase(election.getStatus()) || "ACTIVE".equalsIgnoreCase(election.getStatus())) {
            redirectAttributes.addFlashAttribute("errorMessage", "Election results are sealed until voting is closed by an administrator.");
            return "redirect:/elections/" + id;
        }

        Map<Candidate, Long> results = resultsService.getElectionResults(id);
        long totalVotes = resultsService.getTotalVotesCast(id);

        model.addAttribute("election", election);
        model.addAttribute("results", results);
        model.addAttribute("totalVotes", totalVotes);
        return "results";
    }
}
