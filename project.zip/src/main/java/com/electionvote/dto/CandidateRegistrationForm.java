package com.electionvote.dto;

import org.springframework.web.multipart.MultipartFile;

public class CandidateRegistrationForm {
    private Long candidateId;
    private Long electionId;
    private String name;
    private String party;
    private String position;
    private String constituency;
    private String bio;
    private Boolean approved = true;
    private MultipartFile photo;
    private MultipartFile partySymbol;

    public Long getCandidateId() { return candidateId; }
    public void setCandidateId(Long candidateId) { this.candidateId = candidateId; }

    public Long getElectionId() { return electionId; }
    public void setElectionId(Long electionId) { this.electionId = electionId; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getParty() { return party; }
    public void setParty(String party) { this.party = party; }

    public String getPosition() { return position; }
    public void setPosition(String position) { this.position = position; }

    public String getConstituency() { return constituency; }
    public void setConstituency(String constituency) { this.constituency = constituency; }

    public String getBio() { return bio; }
    public void setBio(String bio) { this.bio = bio; }

    public Boolean getApproved() { return approved; }
    public void setApproved(Boolean approved) { this.approved = approved; }

    public MultipartFile getPhoto() { return photo; }
    public void setPhoto(MultipartFile photo) { this.photo = photo; }

    public MultipartFile getPartySymbol() { return partySymbol; }
    public void setPartySymbol(MultipartFile partySymbol) { this.partySymbol = partySymbol; }
}
