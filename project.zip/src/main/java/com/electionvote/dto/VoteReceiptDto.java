package com.electionvote.dto;

import java.time.LocalDateTime;

public class VoteReceiptDto {
    private String receiptCode;
    private String electionTitle;
    private String candidateName;
    private LocalDateTime timestamp;
    private String verificationHash;

    public VoteReceiptDto() {}
    public VoteReceiptDto(String receiptCode, String electionTitle, String candidateName, LocalDateTime timestamp, String verificationHash) {
        this.receiptCode = receiptCode;
        this.electionTitle = electionTitle;
        this.candidateName = candidateName;
        this.timestamp = timestamp;
        this.verificationHash = verificationHash;
    }

    public String getReceiptCode() { return receiptCode; }
    public void setReceiptCode(String receiptCode) { this.receiptCode = receiptCode; }

    public String getElectionTitle() { return electionTitle; }
    public void setElectionTitle(String electionTitle) { this.electionTitle = electionTitle; }

    public String getCandidateName() { return candidateName; }
    public void setCandidateName(String candidateName) { this.candidateName = candidateName; }

    public LocalDateTime getTimestamp() { return timestamp; }
    public void setTimestamp(LocalDateTime timestamp) { this.timestamp = timestamp; }

    public String getVerificationHash() { return verificationHash; }
    public void setVerificationHash(String verificationHash) { this.verificationHash = verificationHash; }
}
