package com.electionvote.dto;

public class WebAuthnFinishRequest {
    private String challenge;
    private String credentialJson;

    public String getChallenge() { return challenge; }
    public void setChallenge(String challenge) { this.challenge = challenge; }

    public String getCredentialJson() { return credentialJson; }
    public void setCredentialJson(String credentialJson) { this.credentialJson = credentialJson; }
}
