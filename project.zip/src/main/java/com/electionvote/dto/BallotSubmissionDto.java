package com.electionvote.dto;

public class BallotSubmissionDto {
    private Long electionId;
    private Long candidateId;
    private String selectedOptionsJson;
    private String passkeySignature;

    public BallotSubmissionDto() {}

    public Long getElectionId() { return electionId; }
    public void setElectionId(Long electionId) { this.electionId = electionId; }

    public Long getCandidateId() { return candidateId; }
    public void setCandidateId(Long candidateId) { this.candidateId = candidateId; }

    public String getSelectedOptionsJson() { return selectedOptionsJson; }
    public void setSelectedOptionsJson(String selectedOptionsJson) { this.selectedOptionsJson = selectedOptionsJson; }

    public String getPasskeySignature() { return passkeySignature; }
    public void setPasskeySignature(String passkeySignature) { this.passkeySignature = passkeySignature; }
}
