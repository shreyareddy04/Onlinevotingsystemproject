package com.electionvote.dto;

public class WebAuthnOptionsDto {
    private String challenge;
    private String rpId;
    private String userHandle;

    public WebAuthnOptionsDto() {}
    public WebAuthnOptionsDto(String challenge, String rpId, String userHandle) {
        this.challenge = challenge;
        this.rpId = rpId;
        this.userHandle = userHandle;
    }

    public String getChallenge() { return challenge; }
    public void setChallenge(String challenge) { this.challenge = challenge; }

    public String getRpId() { return rpId; }
    public void setRpId(String rpId) { this.rpId = rpId; }

    public String getUserHandle() { return userHandle; }
    public void setUserHandle(String userHandle) { this.userHandle = userHandle; }
}
