package com.electionvote.dto;

import java.util.List;

public record ElectionResultsSnapshot(long totalVotes, List<CandidateTally> candidates) {

    public record CandidateTally(Long candidateId, String candidateName, String party, long votes) {}
}
