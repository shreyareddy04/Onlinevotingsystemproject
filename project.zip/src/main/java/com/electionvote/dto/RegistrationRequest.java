package com.electionvote.dto;

import org.springframework.web.multipart.MultipartFile;

public class RegistrationRequest {
    private String nationalId;
    private String mobileNumber;
    private String constituency;
    private MultipartFile voterIdFront;
    private MultipartFile voterIdBack;
    public RegistrationRequest() {}

    public String getNationalId() { return nationalId; }
    public void setNationalId(String nationalId) { this.nationalId = nationalId; }

    public String getMobileNumber() { return mobileNumber; }
    public void setMobileNumber(String mobileNumber) { this.mobileNumber = mobileNumber; }

    public String getConstituency() { return constituency; }
    public void setConstituency(String constituency) { this.constituency = constituency; }

    public MultipartFile getVoterIdFront() { return voterIdFront; }
    public void setVoterIdFront(MultipartFile voterIdFront) { this.voterIdFront = voterIdFront; }

    public MultipartFile getVoterIdBack() { return voterIdBack; }
    public void setVoterIdBack(MultipartFile voterIdBack) { this.voterIdBack = voterIdBack; }

}
