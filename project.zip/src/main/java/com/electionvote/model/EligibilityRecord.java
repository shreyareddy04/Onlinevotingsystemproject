package com.electionvote.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "eligibility_records", uniqueConstraints = {
    @UniqueConstraint(columnNames = {"voter_id", "election_id"})
})
public class EligibilityRecord {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "voter_id", nullable = false)
    private Voter voter;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "election_id", nullable = false)
    private Election election;

    @Column(name = "is_eligible", nullable = false)
    private boolean eligible = true;

    @Column(name = "has_voted", nullable = false)
    private boolean hasVoted = false;

    @Column(name = "verified_at")
    private LocalDateTime verifiedAt = LocalDateTime.now();

    public EligibilityRecord() {}

    public EligibilityRecord(Voter voter, Election election, boolean eligible, boolean hasVoted) {
        this.voter = voter;
        this.election = election;
        this.eligible = eligible;
        this.hasVoted = hasVoted;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Voter getVoter() { return voter; }
    public void setVoter(Voter voter) { this.voter = voter; }

    public Election getElection() { return election; }
    public void setElection(Election election) { this.election = election; }

    public boolean isEligible() { return eligible; }
    public void setEligible(boolean eligible) { this.eligible = eligible; }

    public boolean isHasVoted() { return hasVoted; }
    public void setHasVoted(boolean hasVoted) { this.hasVoted = hasVoted; }

    public LocalDateTime getVerifiedAt() { return verifiedAt; }
    public void setVerifiedAt(LocalDateTime verifiedAt) { this.verifiedAt = verifiedAt; }
}
