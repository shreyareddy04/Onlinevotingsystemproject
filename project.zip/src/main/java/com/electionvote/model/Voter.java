package com.electionvote.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "voters")
public class Voter {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true)
    private String username;

    @Column(nullable = false, unique = true)
    private String email;

    @Column(nullable = false)
    private String password;

    @Column(name = "full_name")
    private String fullName;

    @Column(name = "national_id")
    private String nationalId;

    @Column(name = "mobile_number")
    private String mobileNumber;

    @Column(name = "constituency")
    private String constituency;

    @Column(name = "voter_id_front_path")
    private String voterIdFrontPath;

    @Column(name = "voter_id_back_path")
    private String voterIdBackPath;

    @Column(name = "otp_verified")
    private Boolean otpVerified = false;

    @Column(name = "biometric_verified")
    private Boolean biometricVerified = false;

    @Column(nullable = false)
    private String role;

    private boolean enabled = true;

    @Column(name = "created_at")
    private LocalDateTime createdAt = LocalDateTime.now();

    public Voter() {}

    public Voter(String username, String email, String password, String fullName, String nationalId, String role) {
        this.username = username;
        this.email = email;
        this.password = password;
        this.fullName = fullName;
        this.nationalId = nationalId;
        this.role = role;
        this.mobileNumber = "9876543210";
        this.constituency = "Hyderabad, Telangana";
    }

    public Voter(String username, String email, String password, String fullName, String nationalId, String mobileNumber, String constituency, String role) {
        this.username = username;
        this.email = email;
        this.password = password;
        this.fullName = fullName;
        this.nationalId = nationalId;
        this.mobileNumber = mobileNumber;
        this.constituency = constituency;
        this.role = role;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }

    public String getFullName() { return fullName; }
    public void setFullName(String fullName) { this.fullName = fullName; }

    public String getNationalId() { return nationalId; }
    public void setNationalId(String nationalId) { this.nationalId = nationalId; }

    public String getMobileNumber() { return mobileNumber; }
    public void setMobileNumber(String mobileNumber) { this.mobileNumber = mobileNumber; }

    public String getConstituency() { return constituency; }
    public void setConstituency(String constituency) { this.constituency = constituency; }

    public String getVoterIdFrontPath() { return voterIdFrontPath; }
    public void setVoterIdFrontPath(String voterIdFrontPath) { this.voterIdFrontPath = voterIdFrontPath; }

    public String getVoterIdBackPath() { return voterIdBackPath; }
    public void setVoterIdBackPath(String voterIdBackPath) { this.voterIdBackPath = voterIdBackPath; }

    public boolean isOtpVerified() { return Boolean.TRUE.equals(otpVerified); }
    public void setOtpVerified(boolean otpVerified) { this.otpVerified = otpVerified; }

    public boolean isBiometricVerified() { return Boolean.TRUE.equals(biometricVerified); }
    public void setBiometricVerified(boolean biometricVerified) { this.biometricVerified = biometricVerified; }

    public String getRole() { return role; }
    public void setRole(String role) { this.role = role; }

    public boolean isEnabled() { return enabled; }
    public void setEnabled(boolean enabled) { this.enabled = enabled; }

    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
}
