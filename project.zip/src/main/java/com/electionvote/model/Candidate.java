package com.electionvote.model;

import jakarta.persistence.*;

@Entity
@Table(name = "candidates")
public class Candidate {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String name;

    private String party;

    private String position;

    private String constituency;

    @Column(columnDefinition = "TEXT")
    private String bio;

    @Column(name = "photo_url")
    private String photoUrl;

    @Column(name = "party_symbol_url")
    private String partySymbolUrl;

    @Column(name = "is_nota")
    private Boolean nota = false;

    @Column(name = "approved")
    private Boolean approved = true;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "election_id", nullable = false)
    private Election election;

    public Candidate() {}

    public Candidate(String name, String party, String position, String bio, String photoUrl, Election election) {
        this.name = name;
        this.party = party;
        this.position = position;
        this.constituency = "Hyderabad, Telangana";
        this.bio = bio;
        this.photoUrl = photoUrl;
        this.election = election;
        this.nota = false;
    }

    public Candidate(String name, String party, String position, String constituency, String bio, String photoUrl, Election election) {
        this.name = name;
        this.party = party;
        this.position = position;
        this.constituency = constituency;
        this.bio = bio;
        this.photoUrl = photoUrl;
        this.election = election;
        this.nota = false;
    }

    public Candidate(String name, Election election, boolean nota) {
        this.name = name;
        this.party = "None";
        this.position = "NOTA Choice";
        this.constituency = "All";
        this.bio = "None of the Above (NOTA) option for voters who do not wish to vote for any listed candidate.";
        this.election = election;
        this.nota = nota;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getParty() { return party; }
    public void setParty(String party) { this.party = party; }

    public String getPosition() { return position; }
    public void setPosition(String position) { this.position = position; }

    public String getConstituency() { return constituency; }
    public void setConstituency(String constituency) { this.constituency = constituency; }

    public boolean isAvailableToConstituency(String voterConstituency) {
        if (position != null && "President".equalsIgnoreCase(position.trim())) return true;
        return constituency == null || constituency.isBlank()
                || "All".equalsIgnoreCase(constituency)
                || voterConstituency != null && constituency.equalsIgnoreCase(voterConstituency);
    }

    public String getBio() { return bio; }
    public void setBio(String bio) { this.bio = bio; }

    public String getPhotoUrl() { return photoUrl; }
    public void setPhotoUrl(String photoUrl) { this.photoUrl = photoUrl; }

    public String getPartySymbolUrl() { return partySymbolUrl; }
    public void setPartySymbolUrl(String partySymbolUrl) { this.partySymbolUrl = partySymbolUrl; }

    public boolean isNota() { return Boolean.TRUE.equals(nota); }
    public void setNota(Boolean nota) { this.nota = nota; }

    public boolean isApproved() { return approved == null || approved; }
    public void setApproved(Boolean approved) { this.approved = approved; }

    public Election getElection() { return election; }
    public void setElection(Election election) { this.election = election; }
}
