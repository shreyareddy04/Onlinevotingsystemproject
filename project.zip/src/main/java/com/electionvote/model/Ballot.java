package com.electionvote.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "ballots")
public class Ballot {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "election_id", nullable = false)
    private Election election;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "candidate_id", nullable = false)
    private Candidate candidate;

    @Column(name = "selected_options_json")
    private String selectedOptionsJson;

    @Column(nullable = false)
    private LocalDateTime timestamp = LocalDateTime.now();

    @Column(name = "encrypted_receipt_hash", length = 512)
    private String encryptedReceiptHash;

    public Ballot() {}

    public Ballot(Election election, Candidate candidate, String selectedOptionsJson, String encryptedReceiptHash) {
        this.election = election;
        this.candidate = candidate;
        this.selectedOptionsJson = selectedOptionsJson;
        this.encryptedReceiptHash = encryptedReceiptHash;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Election getElection() { return election; }
    public void setElection(Election election) { this.election = election; }

    public Candidate getCandidate() { return candidate; }
    public void setCandidate(Candidate candidate) { this.candidate = candidate; }

    public String getSelectedOptionsJson() { return selectedOptionsJson; }
    public void setSelectedOptionsJson(String selectedOptionsJson) { this.selectedOptionsJson = selectedOptionsJson; }

    public LocalDateTime getTimestamp() { return timestamp; }
    public void setTimestamp(LocalDateTime timestamp) { this.timestamp = timestamp; }

    public String getEncryptedReceiptHash() { return encryptedReceiptHash; }
    public void setEncryptedReceiptHash(String encryptedReceiptHash) { this.encryptedReceiptHash = encryptedReceiptHash; }
}
