/**
 * Interactive Ballot Selection Script ("Cart / Checkout" behavior)
 */
let selectedCandidateId = null;

function selectCandidate(candidateId, candidateName) {
    selectedCandidateId = candidateId;
    
    // Uncheck other radio options
    document.querySelectorAll('.candidate-option-card').forEach(card => {
        card.classList.remove('border-primary', 'bg-light');
    });

    const selectedCard = document.getElementById(`candidate-card-${candidateId}`);
    if (selectedCard) {
        selectedCard.classList.add('border-primary', 'bg-light');
    }

    const radioInput = document.getElementById(`candidate-radio-${candidateId}`);
    if (radioInput) {
        radioInput.checked = true;
    }

    const reviewBtn = document.getElementById('reviewBallotBtn');
    if (reviewBtn) {
        reviewBtn.disabled = false;
    }

    const candidateInput = document.getElementById('selectedCandidateIdInput');
    if (candidateInput) {
        candidateInput.value = candidateId;
    }
}
