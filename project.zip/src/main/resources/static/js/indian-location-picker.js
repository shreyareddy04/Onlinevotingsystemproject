(() => {
    const dataUrl = '/data/india-states-districts.json';

    function addOption(select, value, label) {
        const option = document.createElement('option');
        option.value = value;
        option.textContent = label;
        select.append(option);
    }

    function initializePicker(picker, directory) {
        const stateSelect = picker.querySelector('[data-location-state]');
        const districtSelect = picker.querySelector('[data-location-district]');
        const locationInput = picker.querySelector('[data-location-value]');
        const status = picker.querySelector('[data-location-status]');
        const currentValue = locationInput.value.trim();
        const separator = currentValue.lastIndexOf(',');
        const currentDistrict = separator > 0 ? currentValue.slice(0, separator).trim() : '';
        const currentState = separator > 0 ? currentValue.slice(separator + 1).trim() : '';

        addOption(stateSelect, '', 'Select a state or union territory');
        directory.forEach(({ state }) => addOption(stateSelect, state, state));

        function populateDistricts(selectedDistrict = '') {
            districtSelect.replaceChildren();
            addOption(districtSelect, '', 'Select a district');
            const selectedState = directory.find(({ state }) => state === stateSelect.value);
            if (!selectedState) {
                districtSelect.disabled = true;
                locationInput.value = '';
                return;
            }
            selectedState.districts.forEach((district) => addOption(districtSelect, district, district));
            districtSelect.disabled = false;
            districtSelect.value = selectedDistrict;
            updateLocation();
        }

        function updateLocation() {
            locationInput.value = stateSelect.value && districtSelect.value
                ? `${districtSelect.value}, ${stateSelect.value}`
                : '';
        }

        stateSelect.addEventListener('change', () => populateDistricts());
        districtSelect.addEventListener('change', updateLocation);
        stateSelect.value = currentState;
        populateDistricts(currentDistrict);

        if (currentValue && !locationInput.value && status) {
            status.textContent = 'Choose a current district and state from the lists.';
        }
    }

    async function initialize() {
        const pickers = document.querySelectorAll('[data-location-picker]');
        if (!pickers.length) return;
        try {
            const response = await fetch(dataUrl, { cache: 'force-cache' });
            if (!response.ok) throw new Error(`Location directory request failed with HTTP ${response.status}`);
            const directory = await response.json();
            pickers.forEach((picker) => initializePicker(picker, directory));
        } catch (error) {
            console.error('Unable to load the Indian district directory:', error);
            pickers.forEach((picker) => {
                const status = picker.querySelector('[data-location-status]');
                if (status) status.textContent = 'District choices could not be loaded. Refresh and try again.';
            });
        }
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initialize);
    } else {
        initialize();
    }
})();
