function decodeBase64Url(value) {
    const base64 = value.replace(/-/g, '+').replace(/_/g, '/') + '='.repeat((4 - value.length % 4) % 4);
    return Uint8Array.from(atob(base64), character => character.charCodeAt(0));
}

function encodeBase64Url(value) {
    const bytes = new Uint8Array(value);
    let binary = '';
    bytes.forEach(byte => { binary += String.fromCharCode(byte); });
    return btoa(binary).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/g, '');
}

function serializeCredential(credential) {
    const response = credential.response;
    const payload = {
        id: credential.id,
        rawId: encodeBase64Url(credential.rawId),
        type: credential.type,
        response: {
            clientDataJSON: encodeBase64Url(response.clientDataJSON)
        },
        clientExtensionResults: credential.getClientExtensionResults()
    };

    if (response.attestationObject) {
        payload.response.attestationObject = encodeBase64Url(response.attestationObject);
        if (typeof response.getTransports === 'function') {
            payload.response.transports = response.getTransports();
        }
    } else {
        payload.response.authenticatorData = encodeBase64Url(response.authenticatorData);
        payload.response.signature = encodeBase64Url(response.signature);
        if (response.userHandle) {
            payload.response.userHandle = encodeBase64Url(response.userHandle);
        }
    }
    return JSON.stringify(payload);
}

async function requestJson(url, options) {
    const response = await fetch(url, options);
    const result = await response.json();
    if (!response.ok) {
        throw new Error(result.error || 'Passkey verification could not be completed.');
    }
    return result;
}

function requirePasskeySupport() {
    if (!window.isSecureContext || !window.PublicKeyCredential || !navigator.credentials) {
        throw new Error('Passkeys require a secure browser context and a compatible device.');
    }
}

async function registerPasskey() {
    const status = document.getElementById('passkeyMessage');
    if (status) {
        status.textContent = 'Set up your device passkey to continue.';
        status.className = 'alert alert-info';
        status.hidden = false;
    }
    try {
        requirePasskeySupport();
        const responseOptions = await requestJson('/api/webauthn/register/options');
        const options = responseOptions.publicKey;
        const challenge = options.challenge;
        options.challenge = decodeBase64Url(options.challenge);
        options.user.id = decodeBase64Url(options.user.id);
        if (options.excludeCredentials) {
            options.excludeCredentials = options.excludeCredentials.map(item => ({
                ...item,
                id: decodeBase64Url(item.id)
            }));
        }
        const credential = await navigator.credentials.create({ publicKey: options });
        if (!credential) {
            throw new Error('Passkey enrollment was cancelled.');
        }
        await requestJson('/api/webauthn/register/finish', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                challenge,
                credentialJson: serializeCredential(credential)
            })
        });

        const votingButton = document.querySelector('[data-voting-election-id]');
        if (votingButton) {
            await authenticatePasskeyForVote(votingButton.dataset.votingElectionId);
        } else if (document.querySelector('[data-registration-complete="true"]')) {
            window.location.assign('/elections');
        } else if (status) {
            status.textContent = 'Passkey verified and added to your account.';
            status.className = 'alert alert-success';
        }
    } catch (error) {
        if (status) {
            status.textContent = error.message;
            status.className = 'alert alert-danger';
            status.hidden = false;
        }
    }
}

async function authenticatePasskeyForVote(electionId) {
    const status = document.getElementById('passkeyMessage');
    if (status) {
        status.textContent = 'Confirm your identity on your device.';
        status.className = 'alert alert-info';
        status.hidden = false;
    }
    try {
        requirePasskeySupport();
        const responseOptions = await requestJson('/api/webauthn/authenticate/options');
        const options = responseOptions.publicKey;
        const challenge = options.challenge;
        options.challenge = decodeBase64Url(challenge);
        if (options.allowCredentials) {
            options.allowCredentials = options.allowCredentials.map(item => ({
                ...item,
                id: decodeBase64Url(item.id)
            }));
        }
        const credential = await navigator.credentials.get({ publicKey: options });
        if (!credential) {
            throw new Error('Passkey verification was cancelled.');
        }
        await requestJson('/api/webauthn/authenticate/finish', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                challenge,
                credentialJson: serializeCredential(credential)
            })
        });
        window.location.assign(`/ballot/wizard/${encodeURIComponent(electionId)}/step5`);
    } catch (error) {
        if (status) {
            status.textContent = error.message;
            status.className = 'alert alert-danger';
            status.hidden = false;
        }
    }
}
