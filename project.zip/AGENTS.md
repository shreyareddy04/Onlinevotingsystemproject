# Agent Guidance for `election-vote`

This repository provides an end-to-end Spring Boot digital voting application using WebAuthn / Passkeys, Thymeleaf templates, Bootstrap 5 styling, and an H2 embedded database.

## Critical Guidelines for AI Agents

1. **Architecture & Scoping**:
   - Maintain the standard package layout: `com.electionvote.config`, `controller`, `model`, `repository`, `service`, `dto`.
   - Keep Spring Security stateless or session-backed as configured in `SecurityConfig.java`.

2. **WebAuthn / Passkey Integrity**:
   - WebAuthn flow relies on `WebAuthnService.java` and `WebAuthnController.java`.
   - Never remove challenge generation or public key verification steps.

3. **Voting Logic**:
   - Ensure a voter can vote at most once per election. Verify voter eligibility via `EligibilityRecordRepository` and prevent double submission in `VotingService.java`.
   - Generate SHA-256 vote receipts for every cast ballot.

4. **Testing**:
   - Run `mvn test` after making any model, service, or controller changes.
