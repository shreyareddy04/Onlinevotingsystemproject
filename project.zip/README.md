# 🗳️ Election Vote System (`election-vote`)

Secure online election voting platform built with **Spring Boot 3**, **Thymeleaf**, **Bootstrap 5**, **H2 Database**, and **WebAuthn / Passkeys**.

## 🚀 Features

- **Separate voter and administrator accounts**: Voters register with a voter ID, constituency, an Indian mobile number, ID photos, and a device passkey; voter email and password are not required. Constituency names must match the names assigned to candidates by administrators. Administrators can create an account with an email and confirmed password, then log in with those credentials. Open administrator self-registration is for local demos only and must be restricted before real use.
- **Guided sign-in and voting journey**: Voters register with voter ID, Indian mobile number, front/back ID photos, and a device passkey; they then sign in with voter ID and photos, choose an election, confirm their registered mobile with a six-digit code, and verify their passkey before candidate names are shown. Administrators sign in with email and password.
- **Area-specific ballots**: Eligible voters can select one candidate in their constituency or NOTA.
- **Candidate registration and review**: Candidates can submit their profile, party symbol, photo, and manifesto for upcoming elections. Administrators review, edit, and approve submissions; pending profiles remain off voter ballots, and approved profile changes are read from the database.
- **Automatic sign-out**: Casting a ballot records a receipt and ends the voter session.
- **Verifiable Vote Receipts**: Every submitted ballot generates an immutable SHA-256 cryptographic receipt hash.
- **Aggregate Results Dashboard**: Administrators can view live candidate vote totals and a bar chart, including while an election is open. Individual voter choices are not shown in the results; public results remain sealed until voting closes.
- **Admin Control Panel**: Full administration interface to manage elections, candidates, voter registrations, and audit logs.
- **Indian district and state selection**: Registration, voter profiles, and candidate profiles use a shared directory of 784 districts across India's 28 states and 8 union territories. The app stores locations as `District, State` (for example, `Hyderabad, Telangana`) and validates submitted pairs against that directory.

### Local demo verification

- OTPs are sent through MSG91 and verified with the provider; codes expire after five minutes. Configure `MSG91_AUTH_KEY` and `MSG91_OTP_TEMPLATE_ID` as environment variables after setting up an approved MSG91 OTP template and India SMS/DLT requirements. In PowerShell, set both variables in the same terminal before running `mvn spring-boot:run`; never put the secret key in source control or paste it into chat. For local-only UI testing without MSG91, set `DEMO_OTP_FALLBACK_ENABLED=true`: the app advances with a random, five-minute OTP and displays it on the verification page. This bypasses phone possession verification and must never be enabled for a real election or production deployment.
- Passkeys require a supported browser/device and a secure context. For local development, use `http://localhost:8080`.
- Voter sign-in is demo-only: the submitted ID number is matched against voter records in this app. This is not an Election Commission voter-list check, and the ID photos are not authenticated against an official source. A voter ID number alone must not be treated as proof of identity for a real election.
- Register a voter account with the ID and constituency before using voter sign-in. IDs are normalized for letter case, spaces, and hyphens; Indian mobile numbers are stored as ten digits. This local app does not verify voter eligibility against an official registry, and constituency information entered here is not checked against an official source.
- Voter ID uploads are validated as JPEG/PNG images (up to 5 MB each) and stored under `data/private/voter_ids`, outside the public static directory. The local demo does not connect to an official voter registry or automatically establish that an uploaded document is authentic.
- Configure `webauthn.hostname` and `webauthn.origin` to match the deployed HTTPS domain before using passkeys outside local development.
- The district directory at `src/main/resources/static/data/india-states-districts.json` is from [KTBsomen/Indian-state-district-json](https://github.com/KTBsomen/Indian-state-district-json/tree/eca3f1febe35c7c5fc4c3c9bc78e3438529e4c80), pinned to commit `eca3f1febe35c7c5fc4c3c9bc78e3438529e4c80` (2026-09-20). Its README identifies the Government of India IGOD state/district directory as its source. See [THIRD-PARTY-NOTICES.md](THIRD-PARTY-NOTICES.md) for the required MIT license notice. This dataset is provided for convenience; verify administrative boundaries and names against current official records before operational use. Existing exact generic demo labels such as `North District` are migrated to `Hyderabad, Telangana`; this is a placeholder replacement, not a claim about those records' actual locations.

## 📁 Project Structure

```
election-vote/
├── pom.xml
├── README.md
├── AGENTS.md
├── .agent/
│   └── rules/
│       └── project-rules.md
└── src/
    ├── main/
    │   ├── java/com/electionvote/
    │   │   ├── ElectionVoteApplication.java
    │   │   ├── config/        (SecurityConfig, WebAuthnConfig)
    │   │   ├── controller/    (PageController, AuthController, WebAuthnController,
    │   │   │                   ElectionController, BallotController, AdminController)
    │   │   ├── model/         (Voter, PasskeyCredential, Election, Candidate,
    │   │   │                   EligibilityRecord, Ballot, VoteReceipt)
    │   │   ├── repository/    (VoterRepository, PasskeyCredentialRepository, etc.)
    │   │   ├── service/       (VoterService, WebAuthnService, ElectionService, VotingService, ResultsService)
    │   │   └── dto/           (LoginRequest, RegistrationRequest, BallotSubmissionDto, etc.)
    │   └── resources/
    │       ├── application.properties
    │       ├── schema.sql
    │       ├── static/
    │       │   ├── css/       (main.css)
    │       │   ├── js/        (webauthn.js, search.js, ballot.js, app.js)
    │       │   ├── vendor/bootstrap/   (bootstrap.min.css, bootstrap.bundle.min.js)
    │       │   ├── favicon.svg
    │       │   └── favicon.ico
    │       └── templates/
    │           ├── fragments/ (header.html, footer.html)
    │           ├── index.html
    │           ├── elections.html          (browse + search results)
    │           ├── election-detail.html
    │           ├── candidate.html
    │           ├── ballot.html             (the "cart")
    │           ├── review.html             (the "checkout")
    │           ├── confirmation.html
    │           ├── my-votes.html           (the "order history")
    │           ├── results.html
    │           ├── register.html
    │           ├── login.html
    │           ├── account.html
    │           ├── how-it-works.html
    │           ├── help.html
    │           ├── contact.html
    │           ├── privacy.html
    │           ├── terms.html
    │           ├── error.html
    │           └── admin/ (dashboard.html, election-form.html, candidates.html, voters.html)
    └── test/java/com/electionvote/   (VotingServiceTest, WebAuthnFlowTest, PageSmokeTest)
```

## 🛠️ Getting Started

### Prerequisites
- JDK 25+
- Apache Maven 3.8+

### Running the Application
```bash
mvn spring-boot:run
```
Access the application at `http://localhost:8080`.
H2 Console available at `http://localhost:8080/h2-console`.

### Default Test Credentials
- **Admin**: `admin@electionvote.com` / `AdminPass123!`
- **Voter demo ID**: `ABC1234567` (3 uppercase letters followed by 7 digits; upload front and back images; the app performs only a local record match)
