# Upgrade Plan: election-vote (20261005200707)

- **Generated**: 2026-10-06 01:38 +05:30
- **HEAD Branch**: N/A
- **HEAD Commit ID**: N/A

> Notice: This workspace is not a Git repository; upgrade changes cannot be version-controlled during this run.

## Available Tools

**JDKs**
- JDK 21.0.12.1: `C:\Program Files\Eclipse Adoptium\jdk-21.0.12.101-hotspot` (current project JDK, used for baseline)
- JDK 25.0.4.1: `C:\Program Files\Eclipse Adoptium\jdk-25.0.4.101-hotspot` (target JDK, already available)

**Build Tools**
- Maven 3.9.16: `C:\Users\mendu\Downloads\apache-maven-3.9.16-bin\apache-maven-3.9.16`
- Maven Wrapper: not present

## Guidelines

- Upgrade the Java runtime target only; avoid unrelated dependency upgrades.
- Preserve WebAuthn/passkey verification and voting security behavior.

> Note: You can add any specific guidelines or constraints for the upgrade process here if needed, bullet points are preferred.

## Options

- Working branch: N/A (workspace is not a Git repository)
- Run tests before and after the upgrade: true
- Auto-execution mode: true

## Upgrade Goals

- Java runtime target: 25 (latest LTS)

## Technology Stack

| Technology/Dependency | Current | Min Compatible Version | Why Incompatible |
| --------------------- | ------- | ---------------------- | ---------------- |
| Java | 21 | 25 | User requested Java 25 LTS |
| Spring Boot | 3.2.5 | 3.5.16 | Spring Boot 3.2.5's bundled ASM cannot parse Java 25 class-file version 69 during test discovery |
| Maven | 3.9.16 | 3.9.16 | Available Maven version is suitable; no wrapper present |

## Derived Upgrades

- Update the `java.version` Maven property to 25 so Maven compilation and application runtime use Java 25.
- Upgrade the Spring Boot parent to 3.5.16 because Java 25 test execution proves Spring Boot 3.2.5's ASM cannot read class-file major version 69.
- Update repository developer documentation that explicitly describes Java 21 as the project syntax/runtime version or prerequisite.

## Impact Analysis

### Dependency Changes

| File | Dependency | Current | Action | Target | Reason |
| ---- | ---------- | ------- | ------ | ------ | ------ |
| `pom.xml` | `spring-boot-starter-parent` | `3.2.5` | upgrade | `3.5.16` | Java 25 test discovery fails because Spring Boot 3.2.5's bundled ASM cannot parse class-file version 69 |

### Source Code Changes

No Java source changes are indicated by the runtime target update. Existing Java 21 source remains valid on Java 25.

### Configuration Changes

| File | Property/Setting | Current | Required Change | Reason |
| ---- | ---------------- | ------- | --------------- | ------ |
| `pom.xml` | `properties/java.version` | `21` | Set to `25` | Set the Maven compiler and Spring Boot Java target to the requested latest LTS runtime |

### CI/CD Changes

No CI/CD definitions, Dockerfiles, or pipeline files were found in the workspace.

### Documentation Changes

| File | Location | Current | Required Change | Reason |
| ---- | -------- | ------- | --------------- | ------ |
| `.agent/rules/project-rules.md` | Code Style & Standards | Java 21 standard syntax | Update to Java 25 standard syntax | Keep repository development guidance aligned with the runtime target |
| `README.md` | Getting Started / Prerequisites | JDK 21+ | Update to JDK 25+ | State the new runtime prerequisite |

### Risks & Warnings

- **Spring Boot compatibility**: Testing exposed a concrete incompatibility in 3.2.5: bundled ASM rejects Java 25 class-file version 69. Upgrade the Spring Boot parent to 3.5.16, the newest 3.5 release found in Maven metadata, then verify tests and dependency compatibility.
- **No Git repository**: Changes cannot be isolated or committed. Avoid altering unrelated workspace content.

## Upgrade Steps

- Step 1: Setup Environment
  - **Rationale**: Confirm the already-installed Java 25 runtime and Maven are usable for the upgrade.
  - **Changes to Make**: None.
  - **Verification**: Identify JDK 25.0.4.1 and Maven 3.9.16; expected both available.
- Step 2: Setup Baseline
  - **Rationale**: Establish compilation and test results on the current Java 21 runtime before changing the target.
  - **Changes to Make**: None.
  - **Verification**: `mvn clean compile test-compile -q` and `mvn clean test -q` with JDK 21; expected both succeed.
- Step 3: Set Java 25 Runtime Target
  - **Rationale**: Apply the requested runtime target and align the framework with Java 25 class-file support confirmed necessary by baseline tests.
  - **Changes to Make**: Apply all Dependency Changes, Maven configuration, and documentation changes in Impact Analysis.
  - **Verification**: Review all changes and run `mvn clean test-compile -q` under JDK 25; expected production and test sources compile.
- Step 4: CVE Validation
  - **Rationale**: Check the project’s direct dependencies after the upgrade.
  - **Changes to Make**: Scan known, version-resolved direct dependencies; change versions only if required to fix a reported vulnerability.
  - **Verification**: CVE scan; if a fix is required, compile under JDK 25 and rescan.
- Step 5: Final Validation
  - **Rationale**: Confirm all goals and full test behavior on the target runtime.
  - **Changes to Make**: Resolve any compatibility failures found during validation.
  - **Verification**: `mvn clean test-compile -q` and `mvn clean test -q` under JDK 25; expected compilation success and all tests passing.
