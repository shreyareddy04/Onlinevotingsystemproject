# Java Runtime Upgrade Summary

## Outcome

Upgraded the project runtime target from Java 21 to Java 25 LTS. Java 25.0.4.1 is installed and was used for final verification.

## Changes

- Changed the Maven `java.version` property to 25.
- Updated the Spring Boot parent from 3.2.5 to 3.5.16. Java 25 tests initially failed because the older bundled ASM could not parse Java 25 class-file version 69.
- Updated the developer guidance and README prerequisite to Java/JDK 25.
- No Java source changes were required; WebAuthn/passkey and voting security code remained unchanged.

## Validation

| Check | Result |
| ----- | ------ |
| Java 21 baseline compile and test | Passed |
| Baseline tests | 16/16 passed |
| Java 25 clean test-compile | Passed |
| Java 25 clean verify | Passed |
| Final tests | 16/16 passed; 0 failures, errors, or skips |
| Direct dependency CVE scan | No known CVEs requiring fixes |
| JaCoCo coverage | Not available; JaCoCo is not configured in the project |

## Risks and Notes

- The Java 25 / Spring Boot 3.2.5 ASM incompatibility was resolved by upgrading to Spring Boot 3.5.16.
- This workspace is not a Git repository, so changes remain uncommitted and no branch or commit was created.
- No remaining upgrade workarounds or known runtime validation failures.

## Execution

- Execution mode: Auto
- Build tool: Maven 3.9.16
- Runtime: Eclipse Adoptium JDK 25.0.4.1
- Operator: mendu
